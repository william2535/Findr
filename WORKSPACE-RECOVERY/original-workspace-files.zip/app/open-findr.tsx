'use client';

import { useEffect, useId, useRef, useState, type AnchorHTMLAttributes, type MouseEvent } from 'react';
import { repairRedirectedAppShells } from '../lib/offline-recovery.mjs';
import { prepareAppLaunch } from '../lib/app-update.mjs';
import { APP_VERSION } from '../public/app/version.mjs';

const appUrl = '/app/';
type LaunchProgress = {phase: string; percent?: number};
let preparation: Promise<unknown> | undefined;
let latestProgress: LaunchProgress = {phase: 'checking'};
const listeners = new Set<(progress: LaunchProgress) => void>();

function reportProgress(progress: LaunchProgress) {
  latestProgress = progress;
  for (const listener of listeners) listener(progress);
}

function prepareExistingApp() {
  if (!preparation) {
    preparation = (async () => {
      reportProgress({phase: 'checking'});
      try {
        await repairRedirectedAppShells({cacheStorage: window.caches, origin: window.location.origin});
      } catch {
        // An unavailable cache does not prevent a fresh network launch.
      }
      return prepareAppLaunch({
        serviceWorker: 'serviceWorker' in navigator ? navigator.serviceWorker : undefined,
        origin: window.location.origin,
        appPath: appUrl,
        expectedVersion: APP_VERSION,
        onProgress: reportProgress,
      });
    })().catch(error => {
      preparation = undefined;
      throw error;
    });
  }
  return preparation;
}

type OpenFindrProps = Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'href' | 'onClick'> & {
  destination?: '#home' | '#menus' | '#practice' | '#emulator' | '#gent' | '#nano' | '#devices' | '#downloads/all' | '#downloads/saved' | '#identify' | '#faults' | '#helpers' | '#helpers/new';
};

export default function OpenFindr({ children, destination = '#home', ...props }: OpenFindrProps) {
  const [opening, setOpening] = useState(false);
  const [progress, setProgress] = useState<LaunchProgress>(latestProgress);
  const [error, setError] = useState('');
  const openingRef = useRef(false);
  const errorId = useId();
  const targetUrl = appUrl + destination;

  useEffect(() => {
    listeners.add(setProgress);
    // Begin the existing installation's update while the release page is read.
    void prepareExistingApp().catch(() => {});
    const resetOpening = () => {
      openingRef.current = false;
      setOpening(false);
    };
    window.addEventListener('pageshow', resetOpening);
    return () => {
      listeners.delete(setProgress);
      window.removeEventListener('pageshow', resetOpening);
    };
  }, []);

  async function openApp(event: MouseEvent<HTMLAnchorElement>) {
    const target = event.currentTarget.target;
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey ||
      event.shiftKey || event.altKey || (target && target !== '_self') ||
      event.currentTarget.hasAttribute('download')) return;

    event.preventDefault();
    if (openingRef.current) return;
    openingRef.current = true;
    setOpening(true);
    setError('');
    try {
      await prepareExistingApp();
      window.location.assign(targetUrl);
    } catch {
      openingRef.current = false;
      setOpening(false);
      setError('The update is not ready yet. Stay online and tap again. If this continues, refresh this release page. Your saved files are unchanged.');
    }
  }

  const openingLabel = progress.phase === 'downloading'
    ? 'Updating…' + (progress.percent === undefined ? '' : ' ' + progress.percent + '%')
    : progress.phase === 'ready' ? 'Opening…' : 'Checking…';

  return <>
    <a {...props} href={targetUrl} onClick={openApp} aria-busy={opening || undefined} aria-describedby={error ? errorId : undefined}>
      {opening ? openingLabel : children}
    </a>
    {error && <span id={errorId} className="release-launch-error" role="alert">{error}</span>}
  </>;
}
