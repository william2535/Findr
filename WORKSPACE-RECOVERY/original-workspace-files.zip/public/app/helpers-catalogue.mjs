import {LOCAL_MODEL_BYTES,LOCAL_MODEL_RUNTIME_BYTES} from './local-language-resources.mjs';

const list = value => Array.isArray(value) ? value : [];
const text = value => typeof value === 'string' ? value.trim() : '';
const key = value => text(value).toLocaleLowerCase('en-GB').replace(/\s+/g,' ');
const unique = values => [...new Set(values.filter(Boolean))];
const recordIds = item => unique(list(item?.record_ids).concat(list(item?.recordIds)));
const manufacturer = item => text(item?.brand || item?.manufacturer);
const rows = value => value instanceof Map ? [...value.values()] : Array.isArray(value) ? value : list(value?.records);
const bytes = value => typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : null;
const hash = record => key(record?.fileHash || record?.sha256 || record?.contentHash);
const downloadable = record => {try {const url = new URL(record?.url);return ['https:','http:'].includes(url.protocol) && !url.username && !url.password;} catch {return false;}};
const compare = (a,b) => a.localeCompare(b,'en-GB',{numeric:true,sensitivity:'base'});

export function helperDiscipline(value) {
  const name = key(value).replace(/[ _]/g,'-');
  if (!name || name === 'all') return '';
  if (['fire','fire-detection'].includes(name)) return 'fire';
  if (['security','intruder','intruder-alarms'].includes(name)) return 'intruder';
  if (['access','access-control','accesscontrol'].includes(name)) return 'access-control';
  if (['cctv','cctv-recorders'].includes(name)) return 'cctv';
  return 'other';
}

const disciplineOf = item => helperDiscipline(item?.discipline || item?.category) || 'other';
const inDiscipline = (item,discipline) => !discipline || disciplineOf(item) === discipline;
const scopeId = (...parts) => parts.map(part => encodeURIComponent(text(part))).join(':');
const entityLabel = item => [manufacturer(item),text(item?.model)].filter(Boolean).join(' ');
const sameManufacturer = (a,b) => Boolean(key(a)) && key(a) === key(b);
const sameDocument = (a,b) => Boolean(hash(a)) && hash(a) === hash(b);
const decodeId = value => {try {return decodeURIComponent(value);} catch {return value;}};

function equipmentScope(item,kind) {
  return {
    id:scopeId(kind,item.id),kind,label:entityLabel(item),manufacturer:manufacturer(item),model:text(item.model),
    models:unique([item.model,...list(item.part_numbers)]),discipline:disciplineOf(item),confirmed:false,
    [kind === 'panel' ? 'panelId' : 'deviceId']:item.id,recordIds:recordIds(item),
    ...(item.protocol ? {protocol:text(item.protocol)} : {}),
    scopeNote:`Documents explicitly linked to this ${kind} in the catalogue. Confirm the exact model, variant and edition. ${text(item.applicability_limits)}`.trim(),
  };
}

/** Search identifies choices; search words never establish compatibility. */
export function searchHelperScopes({query='',discipline='',panels=[],devices=[],packs=[],devicePacks=[],records=[]}={},options={}) {
  const selectedDiscipline = helperDiscipline(discipline),terms = key(query).split(/\s+/).filter(Boolean);
  const panelRows = rows(panels),deviceRows = rows(devices),documents = rows(records);
  const candidates = [],searchText = new Map();
  const add = (scope,extra='') => {if (inDiscipline(scope,selectedDiscipline)) {candidates.push(scope);searchText.set(scope.id,key(`${scope.label} ${scope.manufacturer} ${scope.model} ${list(scope.models).join(' ')} ${extra}`));}};
  for (const [kind,items] of [['panel',panelRows],['device',deviceRows]]) {
    for (const item of items) add(equipmentScope(item,kind),[...list(item.aliases),...list(item.part_numbers),item.protocol].filter(Boolean).join(' '));
  }
  const brands = new Map(),protocols = new Map();
  for (const item of [...panelRows,...deviceRows,...rows(packs),...rows(devicePacks),...documents]) {
    const brand = manufacturer(item),itemDiscipline = disciplineOf(item);
    if (!brand) continue;
    const id = scopeId('manufacturer',itemDiscipline,key(brand));
    if (!brands.has(id)) brands.set(id,{id,kind:'manufacturer',label:`${brand} · manufacturer collection`,manufacturer:brand,model:'',models:[],discipline:itemDiscipline,confirmed:false,recordIds:[],scopeNote:'Catalogue documents for this manufacturer and discipline. This collection includes different systems; it does not establish compatibility or identify an installed model.'});
    brands.get(id).recordIds.push(...(item.title && item.models ? [item.id] : recordIds(item)));
  }
  for (const item of deviceRows) {
    const protocol = text(item.protocol),brand = manufacturer(item),itemDiscipline = disciplineOf(item);
    if (!protocol || !brand) continue;
    const id = scopeId('protocol',itemDiscipline,key(brand),key(protocol));
    if (!protocols.has(id)) protocols.set(id,{id,kind:'protocol',label:`${brand} · ${protocol}`,manufacturer:brand,model:protocol,models:[],protocol,discipline:itemDiscipline,confirmed:false,recordIds:[],scopeNote:'Device references with this exact recorded manufacturer and protocol. A shared protocol is a search grouping, not evidence that the devices and a panel are compatible. Check the documented variants and firmware.'});
    protocols.get(id).models.push(item.model);
    protocols.get(id).recordIds.push(...recordIds(item));
  }
  for (const scope of [...brands.values(),...protocols.values()]) add({...scope,models:unique(scope.models),recordIds:unique(scope.recordIds)});
  const linked = new Set([...panelRows,...deviceRows].flatMap(recordIds));
  for (const record of documents) {
    const models = unique(list(record.models).map(text));
    // Unpictured products remain searchable. A multi-model document is a
    // documented reference scope, not an asserted compatible product family.
    if (linked.has(record.id) && models.length < 2) continue;
    add({id:scopeId('document-family',record.id),kind:'document-family',documentId:record.id,label:text(record.title) || `${manufacturer(record)} ${models.join(' / ')}`,manufacturer:manufacturer(record),model:models.length === 1 ? models[0] : '',models,discipline:disciplineOf(record),recordIds:[record.id],confirmed:false,scopeNote:`Recorded document scope${models.length ? ': '+models.join('; ') : ' has no model list'}. Confirm the exact variant and edition. Models appearing in one document are not automatically compatible.`});
  }
  const score = scope => {
    if (!terms.length) return ({panel:0,device:1,manufacturer:2,protocol:3,'document-family':4})[scope.kind];
    const search = key(query);
    if ([scope.model,...list(scope.models)].some(model => key(model) === search)) return 0;
    if (key(scope.label) === search) return 1;
    if (scope.kind === 'manufacturer' && key(scope.manufacturer) === search) return 2;
    return ({panel:3,device:4,protocol:5,'document-family':6,manufacturer:7})[scope.kind];
  };
  const limit = Number.isFinite(options.limit) ? Math.max(0,Math.floor(options.limit)) : 60;
  return candidates.filter(scope => terms.every(term => searchText.get(scope.id).includes(term)))
    .sort((a,b) => score(a)-score(b) || compare(a.label,b.label) || compare(a.id,b.id)).slice(0,limit);
}

function resolveScope(scope,context) {
  const {panels,devices,packs,devicePacks,records} = context;
  const kind = scope.kind === 'family' ? scope.familyType || 'document-family' : scope.kind;
  const selectedDiscipline = helperDiscipline(scope.discipline),brand = text(scope.manufacturer);
  const matches = item => inDiscipline(item,selectedDiscipline) && sameManufacturer(manufacturer(item),brand);
  const selected = [],related = [],requiredIds = [],optionalIds = [],issues = [];
  const addEntity = (item,entityKind,relation,target=selected,evidenceIds=[]) => target.push({id:item.id,kind:entityKind,label:entityLabel(item),manufacturer:manufacturer(item),model:item.model,discipline:disciplineOf(item),relation,recordIds:recordIds(item),evidenceRecordIds:evidenceIds,scopeNote:text(item.applicability_limits)});
  if (kind === 'panel' || kind === 'device') {
    const id = scope[kind === 'panel' ? 'panelId' : 'deviceId'] || (text(scope.id).startsWith(kind+':') ? decodeId(text(scope.id).slice(kind.length+1)) : scope.id);
    const item = (kind === 'panel' ? panels : devices).find(row => row.id === id);
    if (!item) issues.push({kind:'missing-scope',message:'This equipment entry is no longer present in the catalogue. Search again or add the exact manual.'});
    else if ((brand && !sameManufacturer(manufacturer(item),brand)) || !inDiscipline(item,selectedDiscipline) || (text(scope.model) && ![item.model,...list(item.aliases),...list(item.part_numbers)].some(model=>key(model)===key(scope.model)))) issues.push({kind:'identity-conflict',message:'The selected manufacturer, model or discipline conflicts with the equipment catalogue entry. Resolve the identity before assigning its manuals.'});
    else {
      addEntity(item,kind,'selected');requiredIds.push(...recordIds(item));
      const direct = new Set(recordIds(item));
      for (const [otherKind,items] of [['panel',panels],['device',devices]]) for (const other of items) {
        if (other.id === item.id || !sameManufacturer(manufacturer(other),manufacturer(item)) || disciplineOf(other) !== disciplineOf(item)) continue;
        const evidence = recordIds(other).filter(id => direct.has(id) && records.has(id));
        if (!evidence.length) continue;
        addEntity(other,otherKind,'shared-manual',related,evidence);
        optionalIds.push(...recordIds(other));
      }
    }
  } else if (kind === 'manufacturer') {
    for (const [entityKind,items] of [['panel',panels],['device',devices]]) for (const item of items.filter(matches)) {addEntity(item,entityKind,'manufacturer-collection');requiredIds.push(...recordIds(item));}
    for (const pack of [...packs,...devicePacks].filter(matches)) optionalIds.push(...recordIds(pack));
    for (const record of records.values()) if (matches(record)) optionalIds.push(record.id);
  } else if (kind === 'protocol') {
    const protocol = key(scope.protocol || scope.model);
    for (const item of devices.filter(item => matches(item) && protocol && key(item.protocol) === protocol)) {addEntity(item,'device','protocol-collection');requiredIds.push(...recordIds(item));}
    if (!selected.length) issues.push({kind:'missing-scope',message:'No exact manufacturer and protocol grouping is present in the catalogue. A protocol name alone cannot establish equipment or manual applicability.'});
  } else if (kind === 'document-family') {
    const id = scope.documentId || (text(scope.id).startsWith('document-family:') ? decodeId(text(scope.id).slice(16)) : list(scope.recordIds)[0]);
    const record = records.get(id);
    if (!record || (brand && !sameManufacturer(manufacturer(record),brand)) || !inDiscipline(record,selectedDiscipline)) issues.push({kind:'missing-scope',recordId:id,message:'The selected document scope is unavailable or conflicts with the chosen manufacturer or discipline.'});
    else {
      requiredIds.push(id);
      for (const [entityKind,items] of [['panel',panels],['device',devices]]) for (const item of items.filter(item => recordIds(item).includes(id))) {addEntity(item,entityKind,'shared-manual',selected,[id]);optionalIds.push(...recordIds(item));}
    }
  } else issues.push({kind:'missing-scope',message:'Choose a catalogue equipment or document scope before preparing this Helper.'});
  return {selected,related,requiredIds:unique(requiredIds),optionalIds:unique(optionalIds).filter(id => !requiredIds.includes(id)),issues};
}

function savedMap(value) {
  if (value instanceof Map) return value;
  if (value instanceof Set) return new Map([...value].map(id => [id,{id}]));
  return new Map(rows(value).map(record => [record.id,record]));
}

/** Estimate a selected subset with the same shared-file accounting as a plan. */
export function estimateHelperDocuments(documents=[],modelState={}) {
  const files = new Map();
  for (const doc of documents) {
    const identity = hash(doc.record) ? 'hash:'+hash(doc.record) : 'id:'+doc.id;
    if (!files.has(identity)) files.set(identity,[]);
    files.get(identity).push(doc);
  }
  let knownBytes=0,downloadBytes=0,savedBytes=0,unknownCount=0,sharedCount=0,unavailableCount=0;
  for (const group of files.values()) {
    const size = group.map(doc=>doc.bytes).find(value=>value!==null) ?? null;
    const saved = group.some(doc=>doc.saved || doc.sharedSaved),available = group.some(doc=>doc.downloadable);
    sharedCount += group.length-1+(group.some(doc=>doc.sharedSaved) ? 1 : 0);
    for (const doc of group) doc.canonicalManualId = group.find(item=>item.saved)?.id || group[0].id;
    if (size === null) unknownCount++;else knownBytes+=size;
    if (saved) savedBytes+=size||0;
    else if (available) downloadBytes+=size||0;
    else unavailableCount++;
  }
  const modelBytes=bytes(modelState.totalBytes) ?? bytes(modelState.model?.bytes) ?? LOCAL_MODEL_BYTES;
  const modelDownloadBytes=modelState.ready===true || modelState.installed===true ? 0 : bytes(modelState.downloadBytes) ?? modelBytes;
  const runtimeBytes=bytes(modelState.model?.runtimeBytes) ?? LOCAL_MODEL_RUNTIME_BYTES;
  const runtimeDownloadBytes=modelState.ready===true || modelState.runtimeReady===true ? 0 : runtimeBytes;
  return {knownBytes,downloadBytes,savedBytes,unknownCount,sharedCount,unavailableCount,fileCount:files.size,documentCount:documents.length,modelBytes,modelDownloadBytes,runtimeBytes,runtimeDownloadBytes,totalDownloadBytes:downloadBytes+modelDownloadBytes+runtimeDownloadBytes,hasUnknownBytes:unknownCount>0,sharedResourcesOnce:true,note:'PDF estimates count identical recorded file hashes once and reuse saved files. The language model and runtime are shared by all Helpers. Unknown PDF sizes, extracted text and browser storage overhead are not included.'};
}

/**
 * Build a reviewable document plan from catalogue links. Co-documentation is
 * explicitly different from compatibility; no fuzzy family expansion occurs.
 */
export function buildHelperPlan(scope={}, {panels=[],devices=[],packs=[],devicePacks=[],records=[],savedManuals=[],modelState={}}={}) {
  scope=scope && typeof scope==='object' ? {...scope} : {};
  const recordMap = new Map(rows(records).map(record=>[record.id,record]));
  const context={panels:rows(panels),devices:rows(devices),packs:rows(packs),devicePacks:rows(devicePacks),records:recordMap};
  const resolved=resolveScope(scope,context),saved=savedMap(savedManuals),missingDocuments=[...resolved.issues],unverified=[];
  const required=new Set(resolved.requiredIds),documents=[];
  for (const id of [...resolved.requiredIds,...resolved.optionalIds]) {
    const record=recordMap.get(id);
    if (!record) {missingDocuments.push({kind:'missing-record',recordId:id,required:required.has(id),message:`Catalogue document ${id} is linked but its record is unavailable.`});continue;}
    const savedCandidate=saved.get(id),conflictingHash=hash(savedCandidate)&&hash(record)&&!sameDocument(savedCandidate,record);
    const actualSaved=conflictingHash?null:savedCandidate,sharedSaved=actualSaved ? null : [...saved.values()].find(item=>sameDocument(item,record));
    const savedStatus=saved.has(id)&&!conflictingHash,available=downloadable(record);
    const doc={id,record,title:record.title||id,required:required.has(id),saved:savedStatus,sharedSaved:Boolean(sharedSaved),savedRecordId:savedStatus?id:sharedSaved?.id||null,status:savedStatus?'saved':available?'downloadable':'unavailable',downloadable:available,bytes:bytes(actualSaved?.bytes)??bytes(sharedSaved?.bytes)??bytes(record.bytes),models:unique(list(record.models)),revision:text(record.revision),reason:required.has(id)?'Explicit document link for the selected catalogue scope. Check the exact model and edition.':'Additional catalogue reference for the selected collection or equipment documented in the same manual. Compatibility is not established.'};
    documents.push(doc);
    if(conflictingHash) unverified.push(`${doc.title} has a saved record with a different file hash. Repair and verify the applicable PDF before treating it as ready.`);
    if (!savedStatus && !sharedSaved && !available) missingDocuments.push({kind:'unavailable-document',recordId:id,required:doc.required,message:`${doc.title} has no saved or downloadable PDF. Add the applicable document or use its online reference.`});
  }
  for (const entity of resolved.selected) if (!entity.recordIds.length) missingDocuments.push({kind:'missing-entity-documents',entityId:entity.id,message:`No manual is explicitly linked to ${entity.label}. Add its exact document before relying on it.`});
  if (!documents.length && !missingDocuments.length) missingDocuments.push({kind:'missing-documents',message:'No documented manuals are linked to this scope. Add the exact installation, user or technical reference.'});
  if (scope.confirmed !== true) unverified.push('The installed model, variant and firmware have not been confirmed.');
  if (['manufacturer','protocol'].includes(scope.kind)) unverified.push('This is a reference collection. Manufacturer or protocol membership does not establish compatibility or identify an installed model.');
  if (resolved.related.length || scope.kind==='document-family') unverified.push('Shared manuals establish documented reference coverage only. They do not establish that all listed equipment is compatible.');
  unverified.push('Panel-to-device compatibility, supported variants and firmware require the applicable manufacturer documentation; no compatibility relationship is inferred from names, appearance, manufacturer or protocol.');
  const requiredDocs=documents.filter(doc=>doc.required),optionalDocs=documents.filter(doc=>!doc.required),estimate=estimateHelperDocuments(documents,modelState||{});
  const entities=[...resolved.selected,...resolved.related];
  const coverage={selectedCount:resolved.selected.length,relatedCount:resolved.related.length,entityCount:entities.length,documentCount:documents.length,requiredCount:requiredDocs.length,optionalCount:optionalDocs.length,savedCount:documents.filter(doc=>doc.saved||doc.sharedSaved).length,missingCount:missingDocuments.length,compatibilityVerified:false,relation:resolved.related.length||scope.kind==='document-family'?'documented-manual-coverage':'explicit-catalogue-links',scopeNote:text(scope.scopeNote),note:'Includes only explicit catalogue document links. Shared-manual and collection membership are not compatibility evidence.'};
  return {scope,entities,coverage,documents,requiredDocs,optionalDocs,manualIds:documents.map(doc=>doc.id),requiredManualIds:resolved.requiredIds,missingDocuments,unverified,estimate,recommendation:optionalDocs.length?'Prepare the complete documented reference set for the widest recorded coverage, or choose fewer manuals and keep the narrower coverage visible.':'Prepare the documents explicitly linked to this scope. Add exact variant, firmware or compatibility references where the catalogue does not establish them.'};
}
