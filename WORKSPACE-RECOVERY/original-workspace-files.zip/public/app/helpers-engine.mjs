import * as quick from './quick-questions-engine.mjs';
import * as diagnostic from './diagnostic-chat-engine.mjs';
import * as terminal from './terminal-flow.mjs';
import {buildFaultLanguageRequest,beginFaultLanguage,applyFaultLanguageReply,failFaultLanguage} from './fault-language.mjs';
import {normaliseManualQuote} from './manual-answers.mjs';

/** A Helper owns its sources and one transcript. The existing evidence engine
 * alone records tests, prerequisites, corrections and outcomes. Language output
 * is source checked or explicitly confirmed before it can affect that engine. */
export const HELPERS_ENGINE_VERSION='2026-11-11.1';
const list=value=>Array.isArray(value)?value:[];
const text=value=>String(value??'');
const clone=value=>structuredClone(value);
const at=options=>Number.isFinite(options?.now)?options.now:Date.now();
const uid=()=>globalThis.crypto?.randomUUID?.()||`helper-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const normal=value=>text(value).normalize('NFKC').toLowerCase().replace(/[’‘]/g,"'").trim().replace(/[.!?]+$/,'').replace(/\s+/g,' ');
const values=value=>value instanceof Map?[...value.values()]:list(value);
const manualId=value=>value?.manualId||value?.id;
const usable=value=>value?.usable===true&&!!value.contentHash&&list(value.pages).some(page=>page.quality?.readable!==false&&text(page.text).trim());
const choice=(value,label)=>({value,label});
const optionsWithNumbers=options=>options.map((option,index)=>({...option,number:index+1}));
const questionLike=raw=>/^(?:how\b|where\b|why\b|what\b|which\b|can (?:you|i)\b|could (?:you|i)\b|is (?:it|the|this|there)\b|does\b|do (?:i|you)\b|tell me\b|show (?:me\b|the\b)|explain\b)/i.test(raw)||/\?$/.test(raw);
const faultLike=raw=>/\b(?:fault|error|trouble|warning|alarm|open circuit|short circuit|loop open|loop short|missing (?:device|detector)|device missing|no (?:power|voltage|communication)|not working|doesn['’]?t work|offline|won['’]?t (?:reset|clear|start)|stays? locked|not unlock|battery fail|earth leakage|intermittent)\b/i.test(raw);
const faultReport=raw=>faultLike(raw)&&(/\b(?:show(?:s|ing)?|display(?:s|ing)?|report(?:s|ing)?|says|have|having|got|keeps?|appeared|still|since|stopped|failed|won['’]?t|not working|offline|intermittent)\b/i.test(raw)||/^\s*(?:loop (?:open|short)|open circuit|short circuit|earth fault|battery fault|power fault|mains fail|device missing|missing device)\b/i.test(raw));
const commands=/^(?:help|manuals|log|back|give up|fault found|resume|continue|copy|export)$/i;

function allowedIds(helper){return new Set(list(helper?.manualIds).map(text).filter(Boolean));}
function scopeOptions(helper,options={}){
 const ids=allowedIds(helper),analyses=[];
 for(const entry of values(options.analyses)){
  const scopedIds=[...new Set([entry?.helperManualId,...list(entry?.helperManualIds),manualId(entry)].filter(id=>ids.has(id)))];
  if(!scopedIds.length||!usable(entry))continue;
  for(const id of scopedIds){
   const analysis={...clone(entry),manualId:id,savedManualId:entry.savedManualId||manualId(entry)};
   if(!analyses.some(prior=>prior.manualId===id))analyses.push(analysis);
  }
 }
 const records=values(options.records||options.catalogue).filter(record=>ids.has(record.id));
 const saved=values(options.savedManuals).filter(record=>ids.has(record.id));
 for(const analysis of analyses){
  if(!records.some(record=>record.id===analysis.manualId))records.push({id:analysis.manualId,title:analysis.title,brand:analysis.identity?.manufacturer,models:analysis.identity?.models||[analysis.identity?.model].filter(Boolean),equipmentType:analysis.identity?.equipmentType});
 }
 return {...options,analyses,records,catalogue:records,savedManuals:saved.length?saved:records,modelReady:options.modelReady===true};
}
function helperIdentity(helper){
 const scope=helper.scope||{},family=scope.kind==='family'||scope.kind==='protocol'||scope.kind==='manufacturer'||scope.kind==='document-family';
 const equipmentType=scope.equipmentType||helper.equipmentType||(scope.kind==='device'?'other':'panel');
 const system=({'access-control':'access','fire-alarm':'fire',security:'intruder','intruder-alarm':'intruder'})[helper.discipline]||helper.discipline||'fire';
 return {id:`${helper.id}:equipment`,manufacturer:scope.manufacturer||'',model:scope.model||scope.family||'',models:list(scope.models),variant:scope.variant||'',firmware:scope.firmware||'',equipmentType,systemTypes:[system],confirmed:scope.confirmed===true&&!family,installedModelConfirmed:scope.confirmed===true&&!family,confirmationSource:'helper_setup',familyOnly:family,requiresVariant:family,exact:!family,documentScopeEstablished:true};
}
function append(c,role,value,details={},options={}){
 const id=details.id||uid();if(c.messages.some(message=>message.id===id))return;
 c.messages.push({id,role,text:text(value),createdAt:at(options),...details});c.updatedAt=at(options);
}
function base(helper,seed={},options={}){
 if(!helper?.id)throw new TypeError('A saved Helper is required.');
 if(seed.helperId&&seed.helperId!==helper.id){const error=new Error('This conversation belongs to another Helper.');error.code='HELPER_SCOPE_MISMATCH';throw error;}
 const c={schemaVersion:1,version:HELPERS_ENGINE_VERSION,mode:'helper',id:uid(),helperId:helper.id,title:'New conversation',createdAt:at(options),updatedAt:at(options),messages:[],handledInputIds:[],mergedMessageIds:[],reports:[],activeChannel:'question',status:'open',...clone(seed)};
 c.helperId=helper.id;c.mode='helper';c.version=HELPERS_ENGINE_VERSION;
 for(const key of ['messages','handledInputIds','mergedMessageIds','reports'])c[key]=list(c[key]);
 // Saved history remains a record. Only documents owned by this Helper may
 // participate in subsequent retrieval, prompts or new diagnostic evidence.
 const ids=allowedIds(helper);
 if(c.questionState){
  c.questionState.manuals=list(c.questionState.manuals).filter(manual=>ids.has(manualId(manual)));
  c.questionState.manualCandidates=list(c.questionState.manualCandidates).filter(manual=>ids.has(manualId(manual)));
  if(c.questionState.pendingGeneration?.passages?.some(p=>p.manualId&&!ids.has(p.manualId))){c.questionState.pendingGeneration=null;c.pendingGeneration=null;}
 }
 if(c.diagnosticSession){c.diagnosticSession.diagnosticChat||={};c.diagnosticSession.diagnosticChat.manuals=list(c.diagnosticSession.diagnosticChat.manuals).filter(manual=>ids.has(manualId(manual)));}
 if(c.pendingGeneration?.effect?.context?.passages?.some(p=>p.manualId&&!ids.has(p.manualId)))c.pendingGeneration=null;
 return c;
}
function sourceRefs(helper,refs,options){
 const ids=allowedIds(helper);
 return list(refs).flatMap(ref=>{
  const analysis=options.analyses.find(a=>a.contentHash===ref.contentHash&&(!ref.manualId||a.manualId===ref.manualId))||options.analyses.find(a=>a.contentHash===ref.contentHash);
  if(ref.manualId&&ids.has(ref.manualId))return [{...clone(ref),...(analysis?.savedManualId?{savedManualId:analysis.savedManualId}:{})}];
  return analysis?[{...clone(ref),manualId:analysis.manualId,savedManualId:analysis.savedManualId||analysis.manualId}]:[];
 });
}
function sync(helper,c,messages,channel,options={}){
 const seen=new Set(c.mergedMessageIds),existing=new Set(c.messages.map(message=>message.id));
 for(const message of list(messages)){
  const key=`${channel}:${message.id}`;if(seen.has(key))continue;seen.add(key);
  if(existing.has(message.id)||message.role==='user')continue;
  if(channel==='question'&&message.terminalPromptKey==='quick-question')continue;
  // Selection/download flows belong to Helper setup; the conversation cannot
  // silently expand its references through the older global catalogue UI.
  if(channel==='question'&&['quick-discovery:','quick-candidates:','quick-download:'].some(prefix=>text(message.terminalPromptKey).startsWith(prefix)))continue;
  append(c,message.role,message.text,{...clone(message),sourceRefs:sourceRefs(helper,message.sourceRefs,options),channel},options);existing.add(message.id);
 }
 c.mergedMessageIds=[...seen];
 return c;
}
function markExisting(c,messages,channel){c.mergedMessageIds=[...new Set([...c.mergedMessageIds,...list(messages).map(message=>`${channel}:${message.id}`)])];}
function waitingManuals(helper,c,options,reason=''){
 const ids=allowedIds(helper),required=list(helper.requiredManualIds).length?helper.requiredManualIds:[...ids];
 const loaded=new Set(options.analyses.map(manual=>manual.manualId));
 const missing=required.filter(id=>!ids.has(id)||!loaded.has(id));
 if(!ids.size&&!missing.length)missing.push('applicable-manual');
 if(!reason&&!missing.length&&loaded.size)return null;
 const message=reason||'A readable manual assigned to this Helper is compulsory. Add or restore the required manual to continue. Your question and current checks are saved.';
 c.manualRequirement={key:'helper-manuals:'+missing.join(','),kind:'manuals',text:message,options:[choice('manuals','Manage Helper manuals')],sourceRefs:[]};
 return {type:'manuals',helperId:helper.id,manualIds:[...ids],missingManualIds:missing,reason:message};
}
function promptMessage(helper,c,options={},force=false){
 const p=getHelperPrompt(helper,c),signature=JSON.stringify([p.key,p.text,p.options]);
 if(p.text&&(force||c.lastPromptSignature!==signature)){
  // Nested engines already supplied this prompt to the unified transcript.
  const last=c.messages.at(-1),same=last?.terminalPromptKey===p.key||last?.helperPromptKey===p.key;
  if(!same||force)append(c,'assistant',p.text,{kind:'helper_prompt',helperPromptKey:p.key,bodyText:p.text,options:p.options,sourceRefs:p.sourceRefs||[],explanation:p.explanation||''},options);
  c.lastPromptSignature=signature;
 }
 return c;
}
function reports(helper,c,options){
 const s=c.diagnosticSession,outcome=s?.diagnosticChat?.outcome;if(!outcome)return;
 const id=`${s.id}:outcome:${outcome.recordedAt||s.diagnosticChat.status}`;if(c.reports.some(report=>report.id===id))return;
 const refs=sourceRefs(helper,[...list(s.diagnosticChat.manuals).map(manual=>({manualId:manual.manualId,contentHash:manual.contentHash,title:manual.title,revision:manual.identity?.revision||''})),...list(s.fieldVisit?.events).flatMap(event=>list(event.sourceRefs)),...c.messages.flatMap(message=>list(message.sourceRefs))],options);
 c.reports.push({id,helperId:helper.id,conversationId:c.id,createdAt:at(options),outcome:clone(outcome),text:diagnostic.getDiagnosticReport(s,{format:'text',redact:false}),sourceRefs:refs.filter((ref,index)=>refs.findIndex(other=>other.manualId===ref.manualId&&other.page===ref.page)===index)});
 c.status=s.diagnosticChat.status;
}
function done(helper,c,effect,options={},force=false){
 if(c.diagnosticSession&&!c.manualRequirement)c.diagnosticPrompt=clone(terminal.getTerminalPrompt(c.diagnosticSession));
 reports(helper,c,options);return {conversation:promptMessage(helper,c,options,force),effect:effect||null};
}

export function createHelperConversation(helper,seed={},options={}){
 const c=base(helper,seed,options);
 // A legacy import already contains its displayed transcript. Consume those
 // nested IDs so reopening it never replays setup or completed questions.
 if(c.messages.length){markExisting(c,c.questionState?.messages,'question');markExisting(c,c.diagnosticSession?.diagnosticChat?.messages,'diagnostic');}
 return promptMessage(helper,c,options);
}

export function getHelperPrompt(helper,conversation){
 const c=conversation||helper;let p;
 if(c.manualRequirement)p=c.manualRequirement;
 else if(c.intentClarification)p={key:'helper-intent:'+c.intentClarification.id,kind:'clarification',text:'Are you asking for the documented meaning or procedure, or reporting a fault that you want to investigate?',options:[choice('explain','Explain it from the manual'),choice('investigate','Investigate this fault')],sourceRefs:[]};
 else if(c.pendingGeneration)p={key:'helper-generating:'+c.pendingGeneration.requestId,kind:'generating',text:c.pendingGeneration.channel==='fault'?'Checking your reply with the local language model.':'Checking the relevant manual passages with the local language model.',options:[],sourceRefs:[]};
 else if(c.activeChannel==='question'&&c.questionState?.pendingQuestionId&&!c.questionState.pendingDiscovery){p=quick.getQuickPrompt(c.questionState);}
 // The public getter never touches a process-global manual registry. A saved
 // case must first resume against this Helper's current readable analyses.
 else if(c.diagnosticSession&&c.activeChannel==='diagnostic')p=c.diagnosticPrompt||{key:'helper-resume-investigation',kind:'resume',text:'Resume this investigation to restore its current manuals and check.',options:[choice('resume','Resume investigation')],sourceRefs:[]};
 else p={key:'helper-ready',kind:'question',text:c.messages.length?'What else would you like to know, or what is happening on site?':'Ask a question or describe what is happening. I’ll use this Helper’s manuals and keep the investigation in this conversation.',options:[],sourceRefs:[]};
 return {...p,options:optionsWithNumbers(list(p.options))};
}

function ensureQuestions(helper,c,options){
 const identity=helperIdentity(helper),old=c.questionState||{};
 for(const analysis of options.analyses)quick.registerQuickManualAnalysis(analysis,{index:analysis.index});
 const manuals=options.analyses.map(analysis=>({...clone(analysis),pages:list(analysis.pages).map(({text:_text,...page})=>page),equipmentId:identity.id,confirmedIdentity:identity,equipmentRole:identity.equipmentType}));
 const state=quick.ensureQuickConversation({...old,id:old.id||`${c.id}:questions`,equipment:[identity],activeEquipmentId:identity.id,manuals,manualCandidates:[],modelState:{ready:options.modelReady},messages:list(old.messages)},options);
 if(!c.questionState)markExisting(c,state.messages,'question');
 c.questionState=state;return state;
}
function normaliseQuestionEffect(helper,c,out,options){
 c.questionState=out.conversation;let effect=out.effect;
 if(effect?.type==='generate'){
  // A content hash may be shared by two saved aliases. Use the current
  // Helper's alias in every exposed passage and citation.
  const remap=passage=>({...passage,...sourceRefs(helper,[passage],options)[0]});
  c.questionState.pendingGeneration.passages=c.questionState.pendingGeneration.passages.map(remap);
  effect={...effect,channel:'question',helperId:helper.id,conversationId:c.id,context:{...effect.context,passages:effect.context.passages.map(remap)}};
  if(!options.modelReady){
   const fallback=quick.applyQuickModelReply(c.questionState,{text:'',limitedFallback:true},{...options,requestId:effect.requestId});
   c.questionState=fallback.conversation;effect=null;
  }else c.pendingGeneration={channel:'question',requestId:effect.requestId,effect:clone(effect)};
 }else if(effect&&['discover_manual','discover','restore_analyses','saved','archive','upload','download','select_manual','model_setup'].includes(effect.type)){
  c.questionState.pendingDiscovery=null;
  effect=waitingManuals(helper,c,options,'The manuals assigned to this Helper do not establish this answer. Add the applicable document to this Helper; the question and investigation remain saved.');
 }
 // A direct exact extraction is useful without a model; label that state
 // explicitly so it cannot be confused with generated language.
 for(const answer of c.questionState.answers||[])if(!answer.helperLabelled){
  answer.helperLabelled=true;
  if(!answer.model?.ran&&!answer.limitedFallback){
   const label=answer.coverage==='reviewed_manual_procedure'?'Documented procedure from the manual. No language model was used.':'Manual extracts only — no language-model answer. Check the cited page for the complete procedure.';
   const message=c.questionState.messages.find(item=>item.answerId===answer.id);
   if(message){message.text=`${label}\n\n${message.text}`;message.model=answer.model;message.retrieval={method:'keyword-and-trade-aliases',semantic:false};}
  }
 }
 sync(helper,c,c.questionState.messages,'question',options);
 if(!c.questionState.pendingQuestionId&&!c.pendingGeneration){
  c.activeChannel=c.diagnosticSession?'diagnostic':'question';
  if(c.activeChannel==='diagnostic')c.lastPromptSignature='';
 }
 return done(helper,c,effect,options);
}
function askQuestion(helper,c,raw,options){
 c.activeChannel='question';ensureQuestions(helper,c,options);
 return normaliseQuestionEffect(helper,c,quick.submitQuickQuestion(c.questionState,raw,options),options);
}

function ensureInvestigation(helper,c,options){
 for(const analysis of options.analyses)diagnostic.registerDiagnosticManualAnalysis(analysis);
 if(c.diagnosticSession){
  // Never let persisted metadata choose a different process-global analysis.
  // Reconstruct current document descriptors from the freshly verified scoped
  // analyses before either legacy engine can read its registry or page cache.
  const chat=c.diagnosticSession.diagnosticChat,prior=list(chat.manuals),identity=helperIdentity(helper),legacyWithoutChat=!chat.phase;
  chat.manuals=options.analyses.map(analysis=>{
   const old=prior.find(manual=>manual.manualId===analysis.manualId&&manual.contentHash===analysis.contentHash&&manual.processorVersion===analysis.processorVersion);
   return {...(old?clone(old):{}),id:analysis.id||analysis.manualId,manualId:analysis.manualId,contentHash:analysis.contentHash,processorVersion:analysis.processorVersion,title:analysis.title||analysis.filename||'Helper manual',filename:analysis.filename||'',pageCount:analysis.pageCount||analysis.pages.length,readablePageCount:analysis.pages.filter(page=>page.quality?.readable!==false&&text(page.text).trim()).length,usable:true,quality:clone(analysis.quality||{}),identity:clone(analysis.identity||{}),pages:analysis.pages.map(({text:_text,...page})=>clone(page)),equipmentRole:old?.equipmentRole||identity.equipmentType};
  });
  c.diagnosticSession=terminal.ensureTerminalSession(c.diagnosticSession,options);
  if(legacyWithoutChat&&identity.confirmed){
   c.diagnosticSession=diagnostic.confirmDiagnosticIdentity(c.diagnosticSession,{step:'system',systemTypes:identity.systemTypes},options);
   c.diagnosticSession=diagnostic.confirmDiagnosticIdentity(c.diagnosticSession,identity,options);
   c.diagnosticSession.diagnosticChat.terminal.stage='engine';
  }
  return c.diagnosticSession;
 }
 const identity=helperIdentity(helper);
 let session=diagnostic.ensureDiagnosticChat({id:`${c.id}:investigation`,started:at(options),panel:{brand:identity.manufacturer,model:identity.model,category:helper.discipline||'fire',record_ids:options.records.map(record=>record.id)},answers:{},notes:'',helperContext:{helperId:helper.id,scope:clone(helper.scope),manualIds:[...allowedIds(helper)],sourcePolicy:'Helper setup is equipment context, never a performed check or a test result.'}},options);
 for(const analysis of options.analyses){
  session=diagnostic.attachDiagnosticManual(session,analysis,{...options,equipmentRole:identity.equipmentType});
  if(session.diagnosticChat.additionalManualConfirmation)session=diagnostic.confirmDiagnosticIdentity(session,{additionalManualId:analysis.manualId,...analysis.identity,equipmentRole:'Helper reference'},options);
 }
 if(identity.confirmed){
  session=diagnostic.confirmDiagnosticIdentity(session,{step:'system',systemTypes:identity.systemTypes},options);
  session=diagnostic.confirmDiagnosticIdentity(session,identity,options);
 }
 session=terminal.ensureTerminalSession(session,options);
 if(identity.confirmed&&session.diagnosticChat.identity.confirmedEquipment){session.diagnosticChat.terminal.stage='engine';session.diagnosticChat.terminal.component={description:identity.equipmentType,manualStatus:'available',manualId:options.analyses[0]?.manualId};}
 markExisting(c,session.diagnosticChat.messages,'diagnostic');c.diagnosticSession=session;
 return session;
}
function diagnosticEffect(helper,c,effect,options){
 if(effect&&['saved','archive','upload'].includes(effect.type))return waitingManuals(helper,c,options,'Add the applicable manual to this Helper before continuing this check.');
 return effect?{...effect,helperId:helper.id,conversationId:c.id}:null;
}

function sourceIsCurrent(helper,passage,options){
 if(!passage?.manualId||!allowedIds(helper).has(passage.manualId)||!passage.contentHash||!Number.isInteger(Number(passage.page)))return false;
 const analysis=options.analyses.find(item=>item.manualId===passage.manualId&&item.contentHash===passage.contentHash);
 if(!analysis||passage.processorVersion&&passage.processorVersion!==analysis.processorVersion)return false;
 const page=list(analysis.pages).find(item=>Number(item.page)===Number(passage.page)&&item.quality?.readable!==false);
 const quote=normaliseManualQuote(passage.text||passage.quote||passage.excerpt||'');
 return !!page&&!!quote&&normaliseManualQuote(page.text).includes(quote);
}
const same=(left,right)=>JSON.stringify(left)===JSON.stringify(right);
function pendingIsCurrent(helper,c,options){
 const pending=c.pendingGeneration,effect=pending?.effect;
 if(!pending||!effect||effect.requestId!==pending.requestId||effect.channel!==pending.channel)return false;
 if(pending.channel==='question'){
  const question=c.questionState?.pendingGeneration;
  if(!question||question.requestId!==pending.requestId||question.questionId!==c.questionState.pendingQuestionId||!list(question.passages).length)return false;
  if(!question.passages.every(passage=>sourceIsCurrent(helper,passage,options))||!list(effect.context?.passages).every(passage=>sourceIsCurrent(helper,passage,options)))return false;
  const projection=passage=>[passage.manualId,passage.contentHash,passage.page,passage.citationId,passage.text];
  if(!same(question.passages.map(projection),list(effect.context?.passages).map(projection)))return false;
  // Persisted prompts are data, including imported manifests. Rebuild the
  // guarded source-selection request from the current Helper and current PDF
  // pages before allowing either model execution or a model completion.
  const rebuiltConversation=clone(c);ensureQuestions(helper,rebuiltConversation,options);
  const rebuilt=quick.resumeQuickQuestion(rebuiltConversation.questionState,{...options,modelReady:true});
  return rebuilt.effect?.type==='generate'&&same(rebuilt.effect.messages,effect.messages)&&same(rebuilt.effect.context?.equipment,effect.context?.equipment)&&same(rebuilt.conversation.pendingGeneration?.equipment,question.equipment)&&rebuilt.effect.context?.question===effect.context?.question;
 }
 if(pending.channel==='fault'){
  const request=pending.request;if(!request||request.id!==pending.requestId||!c.diagnosticSession)return false;
  if(!list(request.passages).every(passage=>sourceIsCurrent(helper,passage,options)))return false;
  const rebuilt=buildFaultLanguageRequest(c.diagnosticSession,request.raw,{analyses:options.analyses,id:request.id});
  return !!rebuilt&&rebuilt.kind===request.kind&&rebuilt.promptKey===request.promptKey&&rebuilt.promptText===request.promptText&&same(rebuilt.messages,request.messages)&&same(rebuilt.messages,effect.messages);
 }
 return false;
}
function invalidatePending(helper,c,options){
 const pending=c.pendingGeneration;c.pendingGeneration=null;
 if(c.questionState&&pending?.channel==='question'){
  c.questionState.pendingGeneration=null;c.questionState.pendingDiscovery=null;c.questionState.notice=null;c.questionState.phase='question';
  const question=list(c.questionState.questions).find(item=>item.id===c.questionState.pendingQuestionId);if(question)question.triedManualIds=[];
 }
 const interaction=list(c.diagnosticSession?.diagnosticChat?.languageInteractions).find(item=>item.id===pending?.requestId);if(interaction)interaction.status='invalidated';
 append(c,'assistant','The saved model request could not be verified against this Helper’s current readable manual pages and current check. Your conversation is retained. Ask again to retrieve the verified sources; no model reply or completed check was accepted.',{kind:'model_request_invalidated',model:{ran:false}},options);
 return done(helper,c,null,options);
}
function investigate(helper,c,raw,options){
 const starting=!c.diagnosticSession;
 c.activeChannel='diagnostic';ensureInvestigation(helper,c,options);
 if(starting&&c.diagnosticSession.diagnosticChat.phase!=='fault'&&!c.diagnosticSession.diagnosticChat.identity.confirmedEquipment){
  c.pendingFault=raw;return done(helper,c,null,options);
 }
 const prompt=terminal.getTerminalPrompt(c.diagnosticSession);
 const request=buildFaultLanguageRequest(c.diagnosticSession,raw,{analyses:options.analyses,id:uid()});
 if(request?.kind==='component_manual'){
  const effect=waitingManuals(helper,c,options,`An applicable ${request.equipmentRole} manual must be assigned to this Helper before answering that. The current diagnostic check is unchanged.`);
  return done(helper,c,effect,options);
 }
 if(request&&options.modelReady){
  c.diagnosticSession=beginFaultLanguage(c.diagnosticSession,request);
  sync(helper,c,c.diagnosticSession.diagnosticChat.messages,'diagnostic',options);
  const effect={type:'generate',channel:'fault',requestId:request.id,messages:request.messages,maxNewTokens:request.maxNewTokens,context:{kind:request.kind,promptKey:request.promptKey,passages:request.passages,manualIds:[...allowedIds(helper)]},helperId:helper.id,conversationId:c.id};
  c.pendingGeneration={channel:'fault',requestId:request.id,request:clone(request),effect:clone(effect)};return done(helper,c,effect,options);
 }
 if(!options.modelReady&&!c.guidedRulesLabelled){append(c,'assistant','Guided rules are active. The local language model is not ready; checks, readings and outcomes use the recorded evidence and manual references.',{kind:'guided_rules',model:{ran:false}},options);c.guidedRulesLabelled=true;}
 const out=terminal.submitTerminalInput(c.diagnosticSession,raw,options);c.diagnosticSession=out.session;
 sync(helper,c,out.session.diagnosticChat.messages,'diagnostic',options);
 if(c.pendingFault&&out.session.diagnosticChat.identity.confirmedEquipment){
  const fault=c.pendingFault;delete c.pendingFault;
  // Identity confirmation moves the legacy terminal to a component question;
  // the Helper already supplies that scope, without completing any checks.
  out.session.diagnosticChat.terminal.stage='engine';return investigate(helper,c,fault,{...options,id:undefined});
 }
 return done(helper,c,diagnosticEffect(helper,c,out.effect,options),options);
}

function classify(raw){
 if(questionLike(raw))return 'question';
 if(faultReport(raw))return 'fault';
 if(faultLike(raw))return 'clarify';
 if(/\b(?:view|read|show|explain|enable|disable|configure|program|procedure|history|walk.?test|menu|rating|terminal|wiring|meaning)\b/i.test(raw))return 'question';
 return 'clarify';
}
export function submitHelperMessage(helper,conversation,value,options={}){
 const c=base(helper,conversation,options),raw=text(value);options=scopeOptions(helper,options);
 if(!raw.trim()||options.id&&c.handledInputIds.includes(options.id))return {conversation:c,effect:null};
 if(options.id)c.handledInputIds.push(options.id);
 append(c,'user',raw,{kind:'helper_input',inputId:options.id},options);
 if(c.title==='New conversation')c.title=raw.trim().slice(0,80);
 c.updatedAt=at(options);
 // A newer input invalidates unfinished model work. Late completions must not
 // answer a superseded question or advance a different diagnostic check.
 if(c.pendingGeneration){c.generationHistory||=[];c.generationHistory.push({...c.pendingGeneration,status:'superseded'});c.pendingGeneration=null;}
 delete c.manualRequirement;
 const missing=waitingManuals(helper,c,options);
 if(missing){c.pendingInput={raw,id:options.id};return done(helper,c,missing,options);}
 if(c.diagnosticSession)ensureInvestigation(helper,c,options);
 if(normal(raw)==='manuals')return done(helper,c,{type:'manuals',helperId:helper.id,manualIds:[...allowedIds(helper)],missingManualIds:[]},options);
 if(normal(raw)==='log')return done(helper,c,{type:'log',helperId:helper.id,conversationId:c.id},options);
 if(c.intentClarification){
  const selected=normal(raw),old=c.intentClarification;
  if(['1','explain','explain it from the manual','meaning','procedure'].includes(selected)){delete c.intentClarification;return askQuestion(helper,c,old.raw,{...options,id:undefined});}
  if(['2','investigate','investigate this fault','fault','diagnose'].includes(selected)){delete c.intentClarification;return investigate(helper,c,old.raw,{...options,id:undefined});}
  delete c.intentClarification;
 }
 if(c.activeChannel==='question'&&c.questionState?.pendingQuestionId&&['answer_scope','question_context','identity_edit','correction_choice','correction_value','variant','question_focus'].includes(c.questionState.phase))return askQuestion(helper,c,raw,options);
 if(c.diagnosticSession){
  const prompt=terminal.getTerminalPrompt(c.diagnosticSession),resolved=terminal.resolveTerminalOption(prompt,raw),stage=c.diagnosticSession.diagnosticChat.terminal?.stage;
  if(commands.test(raw.trim())||resolved||['finish','identity','identity_edit','correction_choice','correction_value','correction_reason','reading_context','blocked_reason'].includes(stage))return investigate(helper,c,raw,options);
  if(questionLike(raw))return askQuestion(helper,c,raw,options);
  return investigate(helper,c,raw,options);
 }
 const kind=classify(raw.trim());
 if(kind==='question')return askQuestion(helper,c,raw,options);
 if(kind==='fault')return investigate(helper,c,raw,options);
 c.intentClarification={id:uid(),raw};return done(helper,c,null,options);
}

export function resumeHelperConversation(helper,conversation,options={}){
 const c=base(helper,conversation,options);options=scopeOptions(helper,options);
 if(!c.messages.length)return done(helper,c,null,options);
 const missing=waitingManuals(helper,c,options);if(missing)return done(helper,c,missing,options);
 delete c.manualRequirement;
 if(c.diagnosticSession)ensureInvestigation(helper,c,options);
 if(c.pendingInput){const pending=c.pendingInput;delete c.pendingInput;
  const kind=classify(pending.raw);if(kind==='question')return askQuestion(helper,c,pending.raw,{...options,id:undefined});
  if(kind==='fault'||c.diagnosticSession)return investigate(helper,c,pending.raw,{...options,id:undefined});
  c.intentClarification={id:uid(),raw:pending.raw};return done(helper,c,null,options);
 }
 if(c.pendingGeneration){
  if(!pendingIsCurrent(helper,c,options))return invalidatePending(helper,c,options);
  if(options.modelReady)return done(helper,c,clone(c.pendingGeneration.effect),options);
  return applyHelperModelReply(helper,c,{error:{code:'MODEL_NOT_READY',message:'Local language resources are not ready.'}},{...options,requestId:c.pendingGeneration.requestId});
 }
 if(c.questionState?.pendingQuestionId&&c.activeChannel==='question'){
  ensureQuestions(helper,c,options);return normaliseQuestionEffect(helper,c,quick.resumeQuickQuestion(c.questionState,options),options);
 }
 if(c.diagnosticSession){ensureInvestigation(helper,c,options);sync(helper,c,c.diagnosticSession.diagnosticChat.messages,'diagnostic',options);}
 return done(helper,c,null,options);
}

export function applyHelperModelReply(helper,conversation,result={},options={}){
 const c=base(helper,conversation,options),pending=c.pendingGeneration;options=scopeOptions(helper,options);
 if(!pending||options.requestId&&pending.requestId!==options.requestId)return {conversation:c,effect:null};
 if(c.diagnosticSession)ensureInvestigation(helper,c,options);
 if(!pendingIsCurrent(helper,c,options))return invalidatePending(helper,c,options);
 c.pendingGeneration=null;
 if(result.error){
  c.lastError={code:text(result.error.code||'MODEL_RUNTIME_ERROR'),message:text(result.error.message||'The local language model could not complete this reply.'),createdAt:at(options),requestId:pending.requestId};
  append(c,'assistant',`Local language model: ${c.lastError.message} (${c.lastError.code}). Your words and the current check are saved. ${pending.channel==='question'?'The following response uses manual extracts only.':'Use the guided options or retry the reply.'}`,{kind:'model_error',error:clone(c.lastError),model:{ran:false}},options);
 }
 if(pending.channel==='question'){
  const out=quick.applyQuickModelReply(c.questionState,result.error?{text:'',limitedFallback:true}:result,{...options,requestId:pending.requestId});
  return normaliseQuestionEffect(helper,c,out,options);
 }
 c.diagnosticSession=result.error?failFaultLanguage(c.diagnosticSession,pending.request,result.error):applyFaultLanguageReply(c.diagnosticSession,pending.request,result);
 sync(helper,c,c.diagnosticSession.diagnosticChat.messages,'diagnostic',options);
 c.activeChannel='diagnostic';return done(helper,c,null,options);
}

export function recordHelperMeasurement(helper,conversation,input,options={}){
 const c=base(helper,conversation,options);options=scopeOptions(helper,options);
 const missing=waitingManuals(helper,c,options);if(missing)return done(helper,c,missing,options);
 ensureInvestigation(helper,c,options);c.activeChannel='diagnostic';
 const raw=input.rawEntry||[input.rawText,input.unit,input.point||input.label,input.reference,input.operatingState].filter(Boolean).join(' ');
 append(c,'user',raw,{kind:'measurement_input',inputId:options.id},options);
 c.diagnosticSession=terminal.recordTerminalMeasurement(c.diagnosticSession,input,options);
 sync(helper,c,c.diagnosticSession.diagnosticChat.messages,'diagnostic',options);return done(helper,c,null,options);
}

export function getHelperReport(helper,conversation,options={}){
 const c=base(helper,conversation,options),report=c.diagnosticSession?diagnostic.getDiagnosticReport(c.diagnosticSession,options):'';
 const transcript=c.messages.map(message=>`${message.role==='user'?'Engineer':'Helper'}: ${message.text}${list(message.sourceRefs).length?'\nSources: '+message.sourceRefs.map(ref=>`${ref.title||ref.manualId}${ref.page?' · PDF page '+ref.page:''}${ref.contentHash?' · '+ref.contentHash:''}`).join('; '):''}`).join('\n\n');
 return [helper.name||'Helper',report,'Conversation',transcript].filter(Boolean).join('\n\n');
}
