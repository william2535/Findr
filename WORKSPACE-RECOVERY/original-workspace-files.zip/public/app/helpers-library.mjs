import * as db from './db.mjs';
import {validatePDF as checkPDF} from './engine.mjs';
import {normalisePDFBlob} from './pdf-runtime.mjs';
import {analyseManual as processManual,getManualAnalysis as readAnalysis,getManualProcessingReadiness as readProcessing,downloadManualProcessingResources as prepareProcessing,MANUAL_ANALYSIS_VERSION,assessPageText} from './manual-analysis.mjs';
import {loadQuickManualIndex as readIndex} from './retrieval-cache.mjs';
import {getLocalLanguageReadiness as readLanguage,prepareLocalLanguageResources as prepareLanguage} from './local-language.mjs';

const ids=helper=>[...new Set((helper?.manualIds||[]).filter(id=>typeof id==='string'&&id))];
const outOfScope=helper=>(helper?.requiredManualIds||[]).filter(id=>!ids(helper).includes(id));
const hash=value=>/^[a-f\d]{64}$/i.test(value||'')?value.toLowerCase():null;
const positive=value=>Number.isFinite(Number(value))&&Number(value)>0?Number(value):0;
const failure=(code,message,cause)=>Object.assign(new Error(message,{cause}),{code});
const detail=error=>({code:error?.code||(error?.name==='QuotaExceededError'?'STORAGE_UNAVAILABLE':'HELPER_PREPARATION_FAILED'),message:String(error?.message||error||'Preparation failed.')});
const cancelled=()=>new DOMException('Helper preparation stopped. Completed manuals and shared resources are kept for retry.','AbortError');
const check=signal=>{if(signal?.aborted)throw cancelled();};
const safeProgress=(callback,value)=>{try{callback?.(value);}catch{/* The UI does not own a preparation job. */}};
const readable=analysis=>analysis?.usable===true&&analysis.processorVersion===MANUAL_ANALYSIS_VERSION&&Array.isArray(analysis.pages)&&analysis.pages.some(page=>page&&assessPageText(page.text||'',page).readable&&page.quality?.readable!==false);
const asMap=value=>value instanceof Map?new Map(value):new Map((Array.isArray(value)?value:[]).map(record=>[record.id,record]));
const modelReady=model=>model?.supported===true&&model.ready===true&&model.installed!==false&&model.runtimeReady!==false&&!model.error&&!model.lastRuntimeError&&model.status!=='error';
const runtimeReady=state=>state?.supported===true&&state.ready===true;

/** Shared PDFs, text and retrieval indexes remain in FINDR's existing stores.
 * Helpers only retain selected IDs and durable queue/progress metadata. */
export function createHelperLibrary(options={}){
 const {downloadManual,refreshSaved=async()=>{},getSaved, getRecords=()=>[],onUpdateHelper,getOfflineReady=()=>false,
  getFile=db.getFile,allManuals=db.allManuals,validatePDF=checkPDF,analyseManual=processManual,getManualAnalysis=readAnalysis,
  loadQuickManualIndex=readIndex,readSetting=db.setting,getLocalLanguageReadiness=readLanguage,prepareLocalLanguageResources=prepareLanguage,
  getManualProcessingReadiness=readProcessing,downloadManualProcessingResources=prepareProcessing,
  storageEstimate=()=>globalThis.navigator?.storage?.estimate?.(),normalizeBlob=normalisePDFBlob}=options;
 const active=new Map(),authoritativeCatalogues=new WeakMap();
 async function savedRecords(){return asMap(getSaved?await getSaved():await allManuals());}
 async function records(helper){
  const catalogue=asMap(await getRecords());authoritativeCatalogues.set(catalogue,new Set(catalogue.keys()));
  for(const doc of helper?.plan?.documents||[]){const record=doc.record||doc;if(record?.id&&!catalogue.has(record.id))catalogue.set(record.id,record);}
  return catalogue;
 }
 function candidates(id,helper,saved,catalogue){
  const source=catalogue.get(id)||saved.get(id),previous=helper.preparation?.[id];
  // A portable plan or unchecked recordId is not proof of document identity.
  // Imports clear these trust fields; only byte-validated bundle/preparation
  // results can establish an identity absent from the local catalogue.
  const trustedSource=authoritativeCatalogues.get(catalogue)?.has(id)?catalogue.get(id):saved.get(id);
  const expected=hash(trustedSource?.sha256)||hash(trustedSource?.fileHash)||(previous?.bytesVerified===true?hash(previous.hash):null);
  const alias=record=>record&&expected&&(hash(record.fileHash)||hash(record.sha256))===expected;
  const previousRecord=saved.get(previous?.recordId);
  const selected=[alias(previousRecord)?previousRecord:null,saved.get(id),...[...saved.values()].filter(alias)].filter(Boolean);
  return {source,expected,records:[...new Map(selected.map(record=>[record.id,record])).values()]};
 }
 async function savedPDF(id,helper,saved,catalogue,{signal}={}){
  const group=candidates(id,helper,saved,catalogue);let invalid=null;
  for(const record of group.records){
   check(signal);
   try{
    const stored=await getFile(record.id);if(!stored)continue;
    const blob=await normalizeBlob(stored);check(signal);
    const actualHash=await validatePDF(blob,group.expected||hash(record.sha256)||hash(record.fileHash));check(signal);
    if(group.expected&&actualHash!==group.expected)throw failure('PDF_INTEGRITY_FAILED','The saved PDF does not match this selected manual. Download the checked copy again.');
    return {id,recordId:record.id,record,blob,hash:actualHash,bytes:blob.size};
   }catch(error){if(error?.name==='AbortError')throw error;invalid=detail(error?.code?error:failure('INVALID_PDF',error.message,error));}
  }
  return {id,ready:false,recordId:null,bytes:0,error:invalid||{code:'MANUAL_MISSING',message:'This selected PDF is not saved on this device.'}};
 }
 async function cachedIndex(analysis,{create=false}={}){
  // The shared cache validates passage text against the analysis. During a
  // readiness check, missing indexes must stay missing; no silent repair/write.
  const settings=create?{}:{read:readSetting,write:async()=>{throw failure('MANUAL_INDEX_MISSING','The saved search index is missing or out of date. Prepare this helper to rebuild it.');},builder:async()=>{throw failure('MANUAL_INDEX_MISSING','A persisted index is required.');}};
  return loadQuickManualIndex(analysis,settings);
 }
 async function inspect(id,helper,saved,catalogue,{signal,createIndex=false}={}){
  const file=await savedPDF(id,helper,saved,catalogue,{signal});if(!file.blob)return {...file,status:file.error.code==='MANUAL_MISSING'?'missing':'error'};
  let analysis;
  try{analysis=await getManualAnalysis(file.hash);}catch(error){return {...file,ready:false,status:'error',error:detail(error)};}
  if(!readable(analysis)||analysis.contentHash!==file.hash)return {...file,ready:false,status:analysis?.usable===false?'error':'pending',error:{code:analysis?.usable===false?'UNREADABLE_MANUAL':'MANUAL_ANALYSIS_MISSING',message:analysis?.usable===false?'The PDF has no reliable readable text. Review or replace it before retrying.':'This saved PDF needs text extraction and indexing.'}};
  analysis={...analysis,manualId:file.recordId,helperManualId:id};
  let result;
  try{result=await cachedIndex(analysis,{create:createIndex});}catch(error){return {...file,ready:false,status:'error',error:detail(error)};}
  const index=result?.index;
  if(!result?.persisted||index?.contentHash!==file.hash||index?.processorVersion!==MANUAL_ANALYSIS_VERSION||!index?.passages?.length)return {...file,ready:false,status:'pending',error:detail(result?.error||failure('MANUAL_INDEX_MISSING','The saved search index is missing. Prepare this helper to rebuild it.'))};
  return {...file,ready:true,status:'ready',error:null,analysis,index,pageCount:analysis.pageCount,processorVersion:analysis.processorVersion,indexBytes:new Blob([JSON.stringify(index)]).size,analysisBytes:new Blob([JSON.stringify(analysis)]).size,warning:result.error?detail(result.error):null};
 }
 async function inspectDocuments(helper,{signal}={}){
  const [saved,catalogue]=await Promise.all([savedRecords(),records(helper)]),documents=[];
  for(const id of ids(helper)){check(signal);try{documents.push(await inspect(id,helper,saved,catalogue,{signal}));}catch(error){if(error?.name==='AbortError')throw error;documents.push({id,ready:false,status:'error',bytes:0,error:detail(error)});}}
  return {saved,catalogue,documents};
 }
 async function environment(){
  const values=await Promise.allSettled([getLocalLanguageReadiness(),getManualProcessingReadiness(),Promise.resolve().then(getOfflineReady),Promise.resolve().then(storageEstimate)]);
  return {model:values[0].status==='fulfilled'?values[0].value:{supported:false,ready:false,error:detail(values[0].reason)},processing:values[1].status==='fulfilled'?values[1].value:{supported:false,ready:false,error:detail(values[1].reason)},shellReady:values[2].status==='fulfilled'&&(values[2].value===true||values[2].value?.ready===true),estimate:values[3].status==='fulfilled'?values[3].value:null};
 }
 function storageSummary(helper,documents,catalogue,environment){
  const verified=new Map(),pending=new Map();let unknownManuals=0;
  for(const document of documents){
   if(document.hash&&document.bytes)verified.set(document.hash,document);
   else{const record=catalogue.get(document.id),key=hash(record?.sha256)||document.id,bytes=positive(record?.bytes);if(bytes)pending.set(key,bytes);else unknownManuals++;}
  }
  for(const key of verified.keys())pending.delete(key);
  const model=environment.model||{},engineBytes=positive(model.model?.bytes)||positive(model.totalBytes),engineAdditionalBytes=positive(model.downloadBytes),engineStoredBytes=Array.isArray(model.files)?model.files.reduce((sum,file)=>sum+positive(file.savedBytes),0):model.installed?engineBytes:Math.max(0,engineBytes-engineAdditionalBytes);
  const manualBytes=[...verified.values()].reduce((sum,row)=>sum+row.bytes,0),analysisBytes=[...verified.values()].reduce((sum,row)=>sum+positive(row.analysisBytes)+positive(row.indexBytes),0),manualAdditionalBytes=[...pending.values()].reduce((sum,size)=>sum+size,0),processingAdditionalBytes=positive(environment.processing?.downloadBytes);
  const usage=Number.isFinite(environment.estimate?.usage)?environment.estimate.usage:null,quota=Number.isFinite(environment.estimate?.quota)?environment.estimate.quota:null;
  return {manualBytes,analysisBytes,storedBytes:manualBytes+analysisBytes,savedBytes:manualBytes+analysisBytes,sharedCount:documents.filter(row=>row.hash&&(row.recordId!==row.id||documents.find(other=>other.hash===row.hash)?.id!==row.id)).length,manualAdditionalBytes,engineBytes,engineStoredBytes,engineAdditionalBytes,processingAdditionalBytes,additionalBytes:manualAdditionalBytes+engineAdditionalBytes+processingAdditionalBytes,unknownManuals,uniqueManuals:verified.size,selectedManuals:ids(helper).length,usage,quota,availableBytes:quota===null?null:Math.max(0,quota-(usage||0)),estimated:true};
 }
 function publicDocument(document){const {blob,record,analysis,index,...rest}=document;return rest;}
 function summary(helper,documents,catalogue,env){
  const allDocumentsReady=documents.length>0&&!outOfScope(helper).length&&documents.every(doc=>doc.ready),aiReady=modelReady(env.model),processingReady=runtimeReady(env.processing),preparing=active.has(helper.id),ready=allDocumentsReady&&aiReady&&processingReady&&env.shellReady&&!preparing;
  const state=preparing?'Preparing':!allDocumentsReady?'Missing manuals':!aiReady||!processingReady||!env.shellReady?'AI unavailable':'Ready offline';
  return {state,status:state,ready,preparing,documents:documents.map(publicDocument),selectedCount:documents.length,readyCount:documents.filter(doc=>doc.ready).length,missingManualIds:[...documents.filter(doc=>!doc.ready).map(doc=>doc.id),...outOfScope(helper)],model:env.model,processing:env.processing,shellReady:env.shellReady,storage:storageSummary(helper,documents,catalogue,env),error:helper.preparationError||helper.modelError||null};
 }
 async function readiness(helper){const [checked,env]=await Promise.all([inspectDocuments(helper),environment()]);return summary(helper,checked.documents,checked.catalogue,env);}
 async function estimate(helper){return (await readiness(helper)).storage;}
 async function loadHelperAnalyses(helper){
  const checked=await inspectDocuments(helper),seen=new Map(),analyses=[];
  for(const document of checked.documents){if(!document.ready)continue;const previous=seen.get(document.hash);if(previous){previous.helperManualIds.push(document.id);continue;}const analysis={...document.analysis,helperManualIds:[document.id],index:document.index};seen.set(document.hash,analysis);analyses.push(analysis);}
  return analyses;
 }
 async function preflight(bytes){
  const estimate=await storageEstimate();
  if(Number.isFinite(estimate?.quota)&&Number.isFinite(estimate?.usage)&&Math.max(0,estimate.quota-estimate.usage)<bytes)throw failure('STORAGE_UNAVAILABLE','There is not enough available browser storage for the selected downloads. Free device storage and retry. Completed manuals are kept.');
 }
 async function prepare(helper,{includeModel=true,signal,onProgress}={}){
  if(!helper?.id)throw failure('HELPER_REQUIRED','Choose a saved helper before preparing its manuals.');
  if(outOfScope(helper).length)throw failure('HELPER_SCOPE_INVALID','Every required manual must be selected in this helper before preparation.');
  if(typeof onUpdateHelper!=='function')throw failure('HELPER_STORAGE_REQUIRED','Helper progress must be saved before preparation can start.');
  if(active.has(helper.id))throw failure('HELPER_BUSY','This helper is already preparing.');
  const controller=new AbortController(),abort=()=>controller.abort();signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)controller.abort();
  const runSignal=controller.signal;active.set(helper.id,controller);
  let current=structuredClone(helper),pendingWrite=Promise.resolve(),writeError=null,wasCancelled=false;const errors=[];
  const persist=(patch={})=>{
   current={...current,...patch,updatedAt:Date.now()};const snapshot=structuredClone(current);
   const write=pendingWrite.then(async()=>{if(writeError)throw writeError;const stored=await onUpdateHelper(snapshot);return stored?.id===snapshot.id?stored:snapshot;});
   pendingWrite=write.catch(error=>{writeError=error;});return write;
  };
  const update=async(id,patch)=>{current.preparation={...(current.preparation||{}),[id]:{...(current.preparation?.[id]||{}),...patch,updatedAt:Date.now()}};return persist();};
  const report=(id,stage,value={})=>{
   const progress={...value,phase:stage};safeProgress(onProgress,{...progress,helperId:current.id,manualId:id||value.manualId||null,completedManuals:ids(current).filter(key=>current.preparation?.[key]?.status==='ready').length,totalManuals:ids(current).length});
   if(id)update(id,{status:stage,progress}).catch(()=>{});
  };
  try{
   check(runSignal);const preparation={...(current.preparation||{})};for(const id of ids(current))preparation[id]={...preparation[id],status:preparation[id]?.status==='ready'?'ready':'queued',error:null};
   await persist({preparation,preparationState:'preparing',preparationError:null,modelError:null});
   const [checked,env]=await Promise.all([inspectDocuments(current,{signal:runSignal}),environment()]);check(runSignal);
   const storage=storageSummary(current,checked.documents,checked.catalogue,env);
   await preflight(storage.manualAdditionalBytes+storage.processingAdditionalBytes+(includeModel?storage.engineAdditionalBytes:0));check(runSignal);
   if(!runtimeReady(env.processing)){
    try{await downloadManualProcessingResources({signal:runSignal,onProgress:value=>report(null,'resources',value)});check(runSignal);}
    catch(error){if(error?.name==='AbortError')throw error;errors.push({stage:'resources',...detail(error)});await persist({preparationError:detail(error)});}
   }
   for(const id of ids(current)){
    check(runSignal);if(writeError)throw writeError;
    try{
     await update(id,{status:'checking',error:null,progress:null});
     let saved=await savedRecords(),catalogue=await records(current),document=await inspect(id,current,saved,catalogue,{signal:runSignal});
     if(document.ready){await update(id,{status:'ready',error:null,hash:document.hash,bytesVerified:true,verification:'helper-pdf-sha256',processorVersion:document.processorVersion,recordId:document.recordId,bytes:document.bytes,pageCount:document.pageCount,progress:null});report(null,'manual-complete',{manualId:id,reused:true});continue;}
     let file=await savedPDF(id,current,saved,catalogue,{signal:runSignal});
     if(!file.blob){
      if(typeof downloadManual!=='function')throw failure('MANUAL_DOWNLOAD_FAILED','This selected manual is not saved. Download its PDF and retry.');
      await update(id,{status:'downloading',error:null});await preflight(positive(catalogue.get(id)?.bytes));
      await downloadManual(id,{signal:runSignal,onProgress:value=>report(id,'downloading',value),replaceInvalid:file.error?.code!=='MANUAL_MISSING'});await pendingWrite;if(writeError)throw writeError;check(runSignal);
      await refreshSaved();saved=await savedRecords();catalogue=await records(current);file=await savedPDF(id,current,saved,catalogue,{signal:runSignal});
      if(!file.blob)throw failure(file.error.code,file.error.message);
     }
     await update(id,{status:'processing',error:null,hash:file.hash,bytesVerified:true,verification:'helper-pdf-sha256',recordId:file.recordId,bytes:file.bytes});
     let analysis=await getManualAnalysis(file.hash);
     if(!readable(analysis))analysis=await analyseManual({blob:file.blob,record:file.record,signal:runSignal,onProgress:value=>report(id,value.phase==='indexing'?'indexing':'processing',value)});
     await pendingWrite;if(writeError)throw writeError;check(runSignal);
     if(!readable(analysis)||analysis.contentHash!==file.hash)throw failure('UNREADABLE_MANUAL','The PDF has no reliable readable text. Review or replace it before retrying.');
     await update(id,{status:'indexing',processorVersion:analysis.processorVersion,pageCount:analysis.pageCount});
     const indexed=await cachedIndex({...analysis,manualId:file.recordId,helperManualId:id},{create:true});check(runSignal);
     if(!indexed?.persisted)throw indexed?.error||failure('MANUAL_INDEX_MISSING','The manual search index could not be saved. Retry preparation.');
     // Completion is only recorded after reading the persisted analysis/index
     // again and validating the exact PDF bytes retained for the next visit.
     document=await inspect(id,current,await savedRecords(),catalogue,{signal:runSignal});
     if(!document.ready)throw failure(document.error?.code||'MANUAL_NOT_READY',document.error?.message||'The saved manual could not be verified.');
     await update(id,{status:'ready',error:null,hash:document.hash,bytesVerified:true,verification:'helper-pdf-sha256',processorVersion:document.processorVersion,recordId:document.recordId,bytes:document.bytes,pageCount:document.pageCount,progress:null,warning:indexed.error?detail(indexed.error):null});
     report(null,'manual-complete',{manualId:id,reused:!!analysis.reused});
    }catch(error){
     await pendingWrite;if(writeError)throw writeError;
     if(error?.name==='AbortError'||runSignal.aborted){await update(id,{status:'cancelled',error:null,progress:null});throw cancelled();}
     const item={id,...detail(error)};errors.push(item);await update(id,{status:'error',error:detail(error),progress:null});safeProgress(onProgress,{phase:'manual-error',helperId:current.id,manualId:id,error:detail(error)});
    }
   }
   check(runSignal);
   if(includeModel){
    const model=await getLocalLanguageReadiness();
    if(!modelReady(model))try{await preflight(positive(model.downloadBytes));await prepareLocalLanguageResources({signal:runSignal,onProgress:value=>report(null,'model',value)});check(runSignal);const after=await getLocalLanguageReadiness();if(!modelReady(after))throw failure('MODEL_NOT_READY',after.message||'The shared local AI resources are not ready offline.');}
    catch(error){if(error?.name==='AbortError')throw error;errors.push({stage:'model',...detail(error)});await persist({modelError:detail(error)});}
   }
  }catch(error){
   wasCancelled=error?.name==='AbortError'||runSignal.aborted;
   if(!wasCancelled){errors.push({stage:'preparation',...detail(error)});current.preparationError=detail(error);}
  }finally{
   signal?.removeEventListener('abort',abort);await pendingWrite;
   current.preparationState=wasCancelled?'cancelled':'idle';
   for(const id of ids(current)){if(['queued','checking','downloading','processing','indexing'].includes(current.preparation?.[id]?.status))current.preparation[id]={...current.preparation[id],status:wasCancelled?'cancelled':'pending',progress:null};}
   try{current=await persist();}finally{active.delete(helper.id);}
  }
  return {helper:current,readiness:await readiness(current),cancelled:wasCancelled,errors};
 }
 return {prepare,readiness,estimate,loadHelperAnalyses,cancel:id=>active.get(id)?.abort(),isPreparing:id=>active.has(id)};
}
