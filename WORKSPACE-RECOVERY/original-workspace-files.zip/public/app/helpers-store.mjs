import {openDB} from './db.mjs';
import {validatePDF} from './engine.mjs';

export const HELPERS_KEY = 'helpers-v1';
export const HELPER_EXPORT_FORMAT = 'findr-helper';
export const HELPER_BUNDLE_TYPE = 'application/vnd.findr.helper';
const BUNDLE_MAGIC = 'FINDR-HELPER-BUNDLE/1\n';
const LEGACY_KEYS = ['quick-questions-v1', 'history', 'session'];
const clone = value => structuredClone(value);
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const nonblank = value => typeof value === 'string' && !!value.trim();
const list = value => Array.isArray(value) ? value : [];
const uid = () => globalThis.crypto?.randomUUID?.() || `helper-${Date.now()}-${Math.random().toString(36).slice(2)}`;
const failure = (message, code = 'HELPERS_INVALID') => Object.assign(new Error(message), {code});
const cancelled = () => new DOMException('The Helper operation was cancelled. Existing records have not been changed.', 'AbortError');
const checkSignal = signal => { if (signal?.aborted) throw cancelled(); };
const time = value => Number.isFinite(value) && value >= 0;
const unique = values => [...new Set(values)];

// Portable state is data only. Reject cyclic/prototype-bearing payloads before
// any transaction, rather than silently dropping evidence during JSON export.
function dataOnly(value, path = 'Helper', seen = new Set()) {
  if (value === null || value === undefined || ['string', 'boolean'].includes(typeof value)) return;
  if (typeof value === 'number' && Number.isFinite(value)) return;
  if (typeof value !== 'object' || seen.has(value) || (!Array.isArray(value) && ![Object.prototype, null].includes(Object.getPrototypeOf(value)))) {
    throw failure(`${path} contains unsupported data.`);
  }
  seen.add(value);
  for (const [key, item] of Object.entries(value)) {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) throw failure(`${path} contains an unsafe field.`);
    dataOnly(item, `${path}.${key}`, seen);
  }
  seen.delete(value);
}
function ids(value, label) {
  if (!Array.isArray(value) || value.some(id => !nonblank(id)) || new Set(value).size !== value.length) throw failure(`${label} must contain unique document IDs.`);
}
function validateConversation(conversation) {
  if (!object(conversation) || !nonblank(conversation.id) || !Array.isArray(conversation.messages)) throw failure('A Helper conversation needs an ID and its complete transcript.');
  if (conversation.title != null && typeof conversation.title !== 'string') throw failure('The conversation title is invalid.');
  if (conversation.messages.some(message => !object(message) || (message.id != null && !nonblank(message.id)) || (message.text != null && typeof message.text !== 'string'))) throw failure('A conversation contains a malformed message.');
  for (const key of ['questionState', 'diagnosticSession']) if (conversation[key] != null && !object(conversation[key])) throw failure('The saved conversation state is invalid.');
  dataOnly(conversation, 'Conversation');
}
export function validateHelper(helper) {
  if (!object(helper) || !nonblank(helper.id) || !nonblank(helper.name)) throw failure('A Helper needs an ID and a name.');
  if (typeof helper.discipline !== 'string') throw failure('The Helper discipline is invalid.');
  if (!object(helper.scope) || !['panel', 'device', 'family', 'protocol', 'manufacturer', 'document-family'].includes(helper.scope.kind)) throw failure('The Helper equipment scope is invalid.');
  if (helper.scope.confirmed != null && typeof helper.scope.confirmed !== 'boolean') throw failure('The Helper equipment confirmation is invalid.');
  ids(helper.manualIds, 'The Helper manual list');
  ids(helper.requiredManualIds, 'The required manual list');
  if (helper.requiredManualIds.some(id => !helper.manualIds.includes(id))) throw failure('Required manuals must also be attached to the Helper.');
  if (!time(helper.createdAt) || !time(helper.updatedAt)) throw failure('The Helper timestamps are invalid.');
  if (!Array.isArray(helper.conversations)) throw failure('The Helper conversations are missing.');
  const conversations = new Set();
  for (const conversation of helper.conversations) {
    validateConversation(conversation);
    if (conversation.helperId != null && conversation.helperId !== helper.id) throw failure('This conversation belongs to another Helper.', 'HELPER_SCOPE_MISMATCH');
    if (conversations.has(conversation.id)) throw failure('The Helper contains duplicate conversation IDs.');
    conversations.add(conversation.id);
  }
  if (helper.activeConversationId != null && !conversations.has(helper.activeConversationId)) throw failure('The active Helper conversation is missing.');
  if (helper.preparation != null && (!object(helper.preparation) || Object.values(helper.preparation).some(item => !object(item)))) throw failure('The Helper preparation record is invalid.');
  dataOnly(helper);
  return clone(helper);
}
export function normalizeHelpersStore(value) {
  if (value === undefined) return {schemaVersion: 1, activeHelperId: null, helpers: [], migration: {sources: []}};
  if (!object(value) || value.schemaVersion !== 1 || !Array.isArray(value.helpers)) throw failure('Saved Helpers cannot be read. Existing records have not been changed.', 'HELPERS_STORAGE_INVALID');
  try {
    const found = new Set();
    for (const helper of value.helpers) {
      validateHelper(helper);
      if (found.has(helper.id)) throw failure('Duplicate Helper IDs.');
      found.add(helper.id);
    }
    if (value.activeHelperId != null && !found.has(value.activeHelperId)) throw failure('The active Helper is missing.');
    if (value.migration != null && (!object(value.migration) || !Array.isArray(value.migration.sources) || value.migration.sources.some(source => !nonblank(source)))) throw failure('The Helper migration record is invalid.');
    dataOnly(value);
  } catch (error) { throw failure(`Saved Helpers cannot be read. ${error.message} Existing records have not been changed.`, 'HELPERS_STORAGE_INVALID'); }
  return {...clone(value), migration: clone(value.migration || {sources: []})};
}

function mergeConversation(previous, incoming) {
  if (!previous) return clone(incoming);
  const incomingNewer = (incoming.updatedAt || 0) >= (previous.updatedAt || 0);
  const newest = incomingNewer ? incoming : previous, older = incomingNewer ? previous : incoming;
  // A stale preparation save must not erase an already committed conversation.
  const messages = clone(older.messages), positions = new Map(messages.map((item, index) => [item.id, index]).filter(([id]) => id));
  for (const message of newest.messages) {
    if (message.id && positions.has(message.id)) messages[positions.get(message.id)] = clone(message);
    else if (message.id || !messages.some(item => JSON.stringify(item) === JSON.stringify(message))) { if (message.id) positions.set(message.id, messages.length); messages.push(clone(message)); }
  }
  return {...clone(older), ...clone(newest), messages};
}
export function mergeHelperSnapshot(value, helper, {activate = true} = {}) {
  const next = normalizeHelpersStore(value), candidate = validateHelper(helper), previous = next.helpers.find(item => item.id === candidate.id);
  if (previous) {
    candidate.createdAt = previous.createdAt;
    const incoming = new Map(candidate.conversations.map(conversation => [conversation.id, conversation]));
    candidate.conversations = previous.conversations.map(conversation => mergeConversation(conversation, incoming.get(conversation.id) || conversation));
    candidate.conversations.push(...helper.conversations.filter(conversation => !previous.conversations.some(item => item.id === conversation.id)).map(clone));
    candidate.updatedAt = Math.max(previous.updatedAt, candidate.updatedAt);
  }
  candidate.revision = (previous?.revision || 0) + 1;
  next.helpers = previous ? next.helpers.map(item => item.id === candidate.id ? candidate : item) : [...next.helpers, candidate];
  if (activate) next.activeHelperId = candidate.id;
  return {store: next, helper: candidate};
}
export function helpersUsingManual(store, manualId) {
  const helpers = Array.isArray(store) ? store : list(store?.helpers);
  return helpers.filter(helper => helper.manualIds?.includes(manualId) || helper.requiredManualIds?.includes(manualId) || Object.values(helper.preparation || {}).some(preparation => preparation.recordId === manualId));
}

export function findLegacyHelper(store, {kind, sourceId} = {}) {
  const sources = kind === 'questions' ? [`quick-questions-v1:${sourceId}`] : [`history:${sourceId}`, `session:${sourceId}`];
  return list(store?.helpers).find(helper => list(helper.legacyOrigin?.sources).some(source => sources.includes(source))) || null;
}

function legacyScope(equipment = {}, kind = 'panel') {
  return {kind, manufacturer: equipment.manufacturer || equipment.brand || '', model: equipment.model || '', variant: equipment.variant || '', firmware: equipment.firmware || '', confirmed: equipment.confirmed === true || equipment.confirmedEquipment === true, ...(equipment.id && kind === 'panel' ? {panelId: equipment.id} : {})};
}
function legacyHelper(id, name, scope, discipline, conversation, manuals, sources, now) {
  const manualIds = unique(manuals.map(manual => manual.manualId || manual.id).filter(nonblank));
  const createdAt = time(conversation.createdAt) ? conversation.createdAt : now;
  return {id, name, discipline: discipline || 'unknown', scope, manualIds, requiredManualIds: [], createdAt, updatedAt: time(conversation.updatedAt) ? conversation.updatedAt : createdAt, conversations: [{...conversation, helperId: id, mode: 'helper'}], activeConversationId: conversation.id, preparation: {}, legacyOrigin: {sources}, revision: 1};
}
/** Copy legacy records once; originals and their shared source documents remain untouched. */
export function migrateLegacyHelpers(value, legacy = {}, now = Date.now()) {
  const next = normalizeHelpersStore(value), completed = new Set(next.migration.sources), warnings = [];
  for (const helper of next.helpers) for (const source of list(helper.legacyOrigin?.sources)) completed.add(source);
  const add = (helper, sources) => {
    if (sources.some(source => completed.has(source))) { for (const source of sources) completed.add(source); return; }
    const base = helper.id; let suffix = 1;
    while (next.helpers.some(item => item.id === helper.id)) helper.id = `${base}-${suffix++}`;
    helper.conversations = helper.conversations.map(conversation => ({...conversation, helperId: helper.id}));
    try { validateHelper(helper); } catch { warnings.push(`A legacy record (${sources.join(', ')}) needs review; its original is unchanged.`); return; }
    next.helpers.push(helper);
    for (const source of sources) completed.add(source);
    next.activeHelperId ||= helper.id;
  };
  const quick = legacy['quick-questions-v1'];
  if (quick != null && (!object(quick) || !Array.isArray(quick.conversations))) warnings.push('Legacy question histories need review; their originals are unchanged.');
  for (const question of list(quick?.conversations)) {
    if (!object(question) || !nonblank(question.id) || !Array.isArray(question.messages)) { warnings.push('A legacy question conversation is malformed; its original is unchanged.'); continue; }
    const equipment = list(question.equipment).find(item => item.id === question.activeEquipmentId) || list(question.equipment)[0] || {};
    const scope = legacyScope(equipment, /panel/i.test(equipment.equipmentType || '') ? 'panel' : 'device');
    const source = `quick-questions-v1:${question.id}`, title = question.title || 'Saved questions';
    const conversation = {id: question.id, title, messages: clone(question.messages), questionState: clone(question), activeChannel: 'question', createdAt: question.createdAt, updatedAt: question.updatedAt};
    add(legacyHelper(`legacy-questions-${encodeURIComponent(question.id)}`, title, scope, equipment.system || equipment.discipline, conversation, list(question.manuals), [source], now), [source]);
  }
  const cases = new Map();
  if (legacy.history != null && !Array.isArray(legacy.history)) warnings.push('Legacy case history needs review; its original is unchanged.');
  for (const entry of list(legacy.history)) {
    if (!object(entry) || !nonblank(entry.id)) { warnings.push('A legacy case is malformed; its original is unchanged.'); continue; }
    cases.set(entry.id, {session: entry, sources: [`history:${entry.id}`]});
  }
  if (legacy.session != null) {
    if (object(legacy.session) && nonblank(legacy.session.id)) {
      const current = legacy.session, prior = cases.get(current.id);
      cases.set(current.id, {session: current, sources: [...(prior?.sources || []), `session:${current.id}`]});
    } else warnings.push('The legacy current session needs review; its original is unchanged.');
  }
  for (const {session, sources} of cases.values()) {
    const chat = session.diagnosticChat || session.fieldVisit?.diagnosticConversation || {}, equipment = {...session.panel, ...chat.identity};
    const scope = legacyScope(equipment); scope.confirmed ||= session.confirmed === true;
    const title = session.site || session.fieldVisit?.siteRef || [scope.manufacturer, scope.model].filter(Boolean).join(' ') || 'Saved fault visit';
    const conversation = {id: session.id, title, messages: clone(list(chat.messages || chat.transcript)), diagnosticSession: clone(session), activeChannel: 'diagnostic', createdAt: session.started || chat.createdAt || now, updatedAt: session.savedAt || chat.updatedAt || session.started || now};
    const manuals = [...list(chat.manuals), ...list(session.panel?.record_ids).map(id => ({manualId: id}))];
    add(legacyHelper(`legacy-case-${encodeURIComponent(session.id)}`, title, scope, session.panel?.category || chat.identity?.system, conversation, manuals, sources, now), sources);
  }
  next.migration = {...next.migration, sources: [...completed], warnings};
  return next;
}

// Every read/modify/write lives in one IndexedDB transaction. Promise resolution
// waits for commit; quota, cancellation, or validation failure exposes no writes.
async function transaction(open, stores, mode, signal, work) {
  checkSignal(signal);
  const database = await open(); checkSignal(signal);
  return new Promise((resolve, reject) => {
    let tx, result, error, settled = false;
    const done = (fn, value) => { if (settled) return; settled = true; signal?.removeEventListener('abort', abortSignal); fn(value); };
    const abort = reason => { error = reason; try { tx.abort(); } catch { done(reject, reason); } };
    const abortSignal = () => abort(cancelled());
    try {
      tx = database.transaction(stores, mode);
      tx.oncomplete = () => done(resolve, result);
      tx.onerror = () => { error ||= tx.error; };
      tx.onabort = () => done(reject, error || tx.error || failure('Device storage is unavailable. Existing Helpers and PDFs have not been changed.', 'HELPERS_STORAGE_FAILED'));
      signal?.addEventListener('abort', abortSignal, {once: true});
      const read = (store, key, callback) => {
        const request = key === undefined ? tx.objectStore(store).getAll() : tx.objectStore(store).get(key);
        request.onsuccess = () => { try { checkSignal(signal); callback(request.result); } catch (reason) { abort(reason); } };
        request.onerror = () => { error ||= request.error; };
      };
      work({tx, read, put: (store, value, key) => key === undefined ? tx.objectStore(store).put(value) : tx.objectStore(store).put(value, key), result: value => { result = clone(value); }, abort});
    } catch (reason) { if (tx) abort(reason); else done(reject, reason); }
  });
}
function readMany(read, entries, callback) {
  const values = Object.create(null); let remaining = entries.length;
  if (!remaining) { callback(values); return; }
  for (const [name, store, key] of entries) read(store, key, value => { values[name] = value; if (!--remaining) callback(values); });
}
function findHelper(store, id) {
  const helper = store.helpers.find(item => item.id === id);
  if (!helper) throw failure('This Helper is no longer saved on this device.', 'HELPER_NOT_FOUND');
  return helper;
}
function makeManifest(helper, manuals = []) {
  const records = new Map(manuals.map(record => [record.id, record]));
  const documents = helper.manualIds.map(id => {
    const preparation = helper.preparation?.[id] || {}, recordId = preparation.recordId || id, record = records.get(recordId);
    return {id, recordId, title: record?.title || id, hash: record?.fileHash || preparation.hash || record?.sha256 || null, bytes: record?.bytes || null, included: false, ...(record ? {record: clone(record)} : {})};
  });
  return {format: HELPER_EXPORT_FORMAT, schemaVersion: 1, exportedAt: Date.now(), helper: clone(helper), documents, portability: {pdfsIncluded: false, includedManualIds: [], missingManualIds: [...helper.manualIds], modelIncluded: false, indexesIncluded: false, readyOnImport: false, note: 'Includes the complete Helper and conversations. PDF files, shared local model, and prepared indexes are separate device resources. Prepare this Helper after importing.'}};
}
export function validateHelperManifest(value) {
  let manifest;
  try { manifest = typeof value === 'string' ? JSON.parse(value) : clone(value); }
  catch { throw failure('The Helper file is not valid JSON.', 'HELPER_IMPORT_INVALID'); }
  dataOnly(manifest, 'Import');
  if (!object(manifest) || manifest.format !== HELPER_EXPORT_FORMAT || manifest.schemaVersion !== 1) throw failure('This file is not a supported FINDR Helper export.', 'HELPER_IMPORT_INVALID');
  validateHelper(manifest.helper);
  if (!Array.isArray(manifest.documents)) throw failure('The Helper export is missing its document manifest.', 'HELPER_IMPORT_INVALID');
  const found = new Set();
  for (const document of manifest.documents) {
    if (!object(document) || !nonblank(document.id) || !manifest.helper.manualIds.includes(document.id) || found.has(document.id) || typeof document.included !== 'boolean') throw failure('The Helper document manifest is invalid.', 'HELPER_IMPORT_INVALID');
    if (document.recordId != null && !nonblank(document.recordId)) throw failure('The Helper document ID is invalid.', 'HELPER_IMPORT_INVALID');
    if (document.hash != null && !/^[a-f0-9]{64}$/i.test(document.hash)) throw failure('The Helper document checksum is invalid.', 'HELPER_IMPORT_INVALID');
    if (document.bytes != null && (!Number.isSafeInteger(document.bytes) || document.bytes < 0)) throw failure('The Helper document size is invalid.', 'HELPER_IMPORT_INVALID');
    if (document.record != null && (!object(document.record) || !nonblank(document.record.id))) throw failure('The exported PDF metadata is invalid.', 'HELPER_IMPORT_INVALID');
    if (document.included && (!document.hash || !Number.isSafeInteger(document.bytes) || document.bytes <= 0)) throw failure('An included PDF is missing its size or checksum.', 'HELPER_IMPORT_INVALID');
    found.add(document.id);
  }
  if (found.size !== manifest.helper.manualIds.length) throw failure('The Helper document manifest is incomplete.', 'HELPER_IMPORT_INVALID');
  return manifest;
}

/** A small JSON manifest followed by raw Blob parts: no PDF/base64 JSON expansion. */
export async function readHelperBundle(blob, {signal} = {}) {
  checkSignal(signal);
  if (!(blob instanceof Blob)) throw failure('Choose a Helper export file.', 'HELPER_IMPORT_INVALID');
  const prefix = new TextDecoder().decode(await blob.slice(0, BUNDLE_MAGIC.length + 32).arrayBuffer()); checkSignal(signal);
  if (!prefix.startsWith(BUNDLE_MAGIC)) {
    const manifest = validateHelperManifest(await blob.text());
    if (manifest.documents.some(document => document.included)) throw failure('This export declares PDF files, but their bytes are missing.', 'HELPER_IMPORT_INVALID');
    return {manifest, files: []};
  }
  const end = prefix.indexOf('\n', BUNDLE_MAGIC.length), lengthText = prefix.slice(BUNDLE_MAGIC.length, end), length = Number(lengthText);
  if (end < 0 || !/^\d+$/.test(lengthText) || !Number.isSafeInteger(length) || length <= 0 || end + 1 + length > blob.size) throw failure('The Helper bundle header is incomplete or invalid.', 'HELPER_IMPORT_INVALID');
  let offset = end + 1 + length;
  const manifest = validateHelperManifest(await blob.slice(end + 1, offset).text()), files = []; checkSignal(signal);
  for (const document of manifest.documents.filter(document => document.included)) {
    checkSignal(signal);
    if (offset + document.bytes > blob.size) throw failure('The Helper bundle contains an incomplete PDF. Existing records have not been changed.', 'HELPER_IMPORT_INVALID');
    const file = blob.slice(offset, offset + document.bytes, 'application/pdf'); offset += document.bytes;
    const hash = await validatePDF(file, document.hash.toLowerCase()); checkSignal(signal);
    files.push({document, blob: file, hash});
  }
  if (offset !== blob.size) throw failure('The Helper bundle contains unrecognised trailing data.', 'HELPER_IMPORT_INVALID');
  return {manifest, files};
}

export function createHelpersStore(open = openDB) {
  async function loadHelpers({migrate = true, signal} = {}) {
    return transaction(open, ['settings'], migrate ? 'readwrite' : 'readonly', signal, ({read, put, result}) => {
      readMany(read, [[HELPERS_KEY, 'settings', HELPERS_KEY], ...(migrate ? LEGACY_KEYS.map(key => [key, 'settings', key]) : [])], values => {
        const previous = values[HELPERS_KEY], store = migrate ? migrateLegacyHelpers(previous, values) : normalizeHelpersStore(previous);
        if (migrate && JSON.stringify(store) !== JSON.stringify(previous)) put('settings', store, HELPERS_KEY);
        result(store);
      });
    });
  }
  async function saveHelper(helper, options = {}) {
    const candidate = validateHelper(helper);
    return transaction(open, ['settings'], 'readwrite', options.signal, ({read, put, result}) => read('settings', HELPERS_KEY, previous => {
      if (options.requireExisting && !normalizeHelpersStore(previous).helpers.some(item => item.id === candidate.id)) throw failure('This Helper was deleted. Its pending work has stopped.', 'HELPER_DELETED');
      const merged = mergeHelperSnapshot(previous, candidate, options);
      put('settings', merged.store, HELPERS_KEY); result(merged.helper);
    }));
  }
  async function updateHelper(id, changes, options = {}) {
    const patch = clone(changes); dataOnly(patch);
    return transaction(open, ['settings'], 'readwrite', options.signal, ({read, put, result}) => read('settings', HELPERS_KEY, value => {
      const store = normalizeHelpersStore(value), previous = findHelper(store, id), candidate = {...previous, ...patch, id, createdAt: previous.createdAt, updatedAt: Date.now()};
      const merged = mergeHelperSnapshot(store, candidate, {activate: false, ...options});
      put('settings', merged.store, HELPERS_KEY); result(merged.helper);
    }));
  }
  const renameHelper = (id, name, options = {}) => {
    if (!nonblank(name)) return Promise.reject(failure('Give this Helper a name.'));
    return updateHelper(id, {name: name.trim()}, options);
  };
  async function saveHelperConversation(id, conversation, options = {}) {
    validateConversation(conversation);
    if (conversation.helperId != null && conversation.helperId !== id) throw failure('This conversation belongs to another Helper.', 'HELPER_SCOPE_MISMATCH');
    const candidate = clone(conversation);
    return transaction(open, ['settings'], 'readwrite', options.signal, ({read, put, result}) => read('settings', HELPERS_KEY, value => {
      const store = normalizeHelpersStore(value), helper = findHelper(store, id);
      candidate.helperId = id;
      const updated = {...helper, conversations: [candidate], updatedAt: Math.max(Date.now(), candidate.updatedAt || 0), activeConversationId: options.activate === false ? helper.activeConversationId : candidate.id};
      // Validation checks active conversation membership before the merge.
      updated.conversations = helper.conversations.filter(item => item.id !== candidate.id).concat(candidate);
      const merged = mergeHelperSnapshot(store, updated, options);
      put('settings', merged.store, HELPERS_KEY); result(merged.helper);
    }));
  }
  async function deleteHelper(id, {signal} = {}) {
    // Deliberately only the settings store: PDFs/indexes/model are shared.
    return transaction(open, ['settings'], 'readwrite', signal, ({read, put, result}) => read('settings', HELPERS_KEY, value => {
      const store = normalizeHelpersStore(value);
      store.helpers = store.helpers.filter(helper => helper.id !== id);
      if (store.activeHelperId === id) store.activeHelperId = store.helpers.at(-1)?.id || null;
      put('settings', store, HELPERS_KEY); result(store);
    }));
  }
  async function setActiveHelper(id, {signal} = {}) {
    return transaction(open, ['settings'], 'readwrite', signal, ({read, put, result}) => read('settings', HELPERS_KEY, value => {
      const store = normalizeHelpersStore(value);
      if (id !== null) findHelper(store, id);
      store.activeHelperId = id; put('settings', store, HELPERS_KEY); result(store);
    }));
  }
  async function exportSnapshot(id, signal, includeFiles) {
    return transaction(open, includeFiles ? ['settings', 'manuals', 'files'] : ['settings', 'manuals'], 'readonly', signal, ({read, result}) => {
      readMany(read, [['helpers', 'settings', HELPERS_KEY], ['manuals', 'manuals', undefined]], values => {
        const helper = findHelper(normalizeHelpersStore(values.helpers), id), manifest = makeManifest(helper, values.manuals);
        if (!includeFiles) { result({manifest, files: {}}); return; }
        const recordIds = unique(manifest.documents.map(document => document.recordId));
        readMany(read, recordIds.map(recordId => [recordId, 'files', recordId]), files => result({manifest, files}));
      });
    });
  }
  async function exportHelper(id, {signal} = {}) { return (await exportSnapshot(id, signal, false)).manifest; }
  async function exportHelperBundle(id, {signal} = {}) {
    const {manifest, files} = await exportSnapshot(id, signal, true), parts = [];
    for (const document of manifest.documents) {
      checkSignal(signal); const file = files[document.recordId];
      if (!(file instanceof Blob) || !file.size) continue;
      const hash = await validatePDF(file, document.hash || undefined); checkSignal(signal);
      document.hash = hash; document.bytes = file.size; document.included = true;
      parts.push(file);
    }
    manifest.portability.pdfsIncluded = parts.length > 0;
    manifest.portability.includedManualIds = manifest.documents.filter(document => document.included).map(document => document.id);
    manifest.portability.missingManualIds = manifest.documents.filter(document => !document.included).map(document => document.id);
    manifest.portability.note = 'Includes the complete Helper, conversations, and available PDF bytes. Missing PDFs are listed. Shared local model and prepared indexes must be prepared on the receiving device.';
    const header = new Blob([JSON.stringify(manifest)], {type: 'application/json'});
    return new Blob([BUNDLE_MAGIC, `${header.size}\n`, header, ...parts], {type: HELPER_BUNDLE_TYPE});
  }
  async function importHelper(input, {signal, newId = uid(), name} = {}) {
    checkSignal(signal);
    const parsed = input instanceof Blob ? await readHelperBundle(input, {signal}) : {manifest: validateHelperManifest(input), files: []};
    const {manifest, files} = parsed;
    if (manifest.documents.some(document => document.included) && !files.length) throw failure('This export declares PDF files, but their bytes are missing.', 'HELPER_IMPORT_INVALID');
    if (!nonblank(newId)) throw failure('The imported Helper needs a valid new ID.');
    const candidate = clone(manifest.helper), originalId = candidate.id;
    candidate.id = newId; candidate.name = name === undefined ? candidate.name : name;
    candidate.conversations = candidate.conversations.map(conversation => {
      const imported = {...conversation, helperId: newId, pendingGeneration: null};
      // Current controls are rebuilt from this device's verified sources. The
      // historical transcript remains exactly as it appeared in the export.
      delete imported.diagnosticPrompt;
      delete imported.manualRequirement;
      imported.lastPromptSignature = '';
      if (Array.isArray(imported.reports)) imported.reports = imported.reports.map(report => ({...report, helperId: newId}));
      if (imported.questionState) {
        imported.questionState.pendingGeneration = null; imported.questionState.pendingDiscovery = null;
        imported.questionState.phase = 'question';
        imported.questionState.notice = null;
        imported.questionState.answerClarification = null;
        imported.questionState.proposedManual = null;
        imported.questionState.pendingIdentity = null;
        imported.questionState.proposedEquipment = null;
        imported.questionState.manualCandidates = [];
        imported.questionState.lastPromptSignature = '';
      }
      const chat = imported.diagnosticSession?.diagnosticChat;
      if (chat) {
        chat.pendingGeneration = null;
        if (chat.terminal) { chat.terminal.languageProposal = null; chat.terminal.notice = null; chat.terminal.lastPromptSignature = ''; }
        if (Array.isArray(chat.languageInteractions)) chat.languageInteractions = chat.languageInteractions.map(item => item.status === 'pending' ? {...item, status: 'cancelled', reason: 'Imported history; verify current sources before requesting a new answer.'} : item);
      }
      return imported;
    });
    candidate.importedFrom = {helperId: originalId, exportedAt: manifest.exportedAt || null, importedAt: Date.now()};
    delete candidate.legacyOrigin;
    delete candidate.plan;
    candidate.updatedAt = Date.now(); candidate.revision = 0;
    candidate.preparationState = 'idle'; candidate.preparationError = null; candidate.modelError = null;
    candidate.preparation = Object.fromEntries(candidate.manualIds.map(id => [id, {status: 'missing', error: null, progress: null}]));
    candidate.portability = {...manifest.portability, readyOnImport: false, indexesIncluded: false, modelIncluded: false};
    validateHelper(candidate); checkSignal(signal);
    return transaction(open, files.length ? ['settings', 'manuals', 'files'] : ['settings'], 'readwrite', signal, ({read, put, result}) => {
      readMany(read, [['helpers', 'settings', HELPERS_KEY], ...(files.length ? [['manuals', 'manuals', undefined]] : [])], values => {
        const store = normalizeHelpersStore(values.helpers);
        if (store.helpers.some(helper => helper.id === newId)) throw failure('A Helper with this ID already exists. Existing Helpers have not been changed.', 'HELPER_IMPORT_CONFLICT');
        const manuals = new Map(list(values.manuals).map(record => [record.id, record]));
        const commit = storedFiles => {
          for (const {document, blob, hash} of files) {
            const sameHash = [...manuals.values()].find(record => (record.fileHash || record.sha256) === hash && storedFiles[record.id] instanceof Blob && storedFiles[record.id].size === blob.size);
            let recordId = sameHash?.id || document.recordId || document.id;
            if (!sameHash && manuals.has(recordId)) recordId = `${recordId}-import-${hash.slice(0,16)}`;
            const base = recordId; let suffix = 1;
            while (!sameHash && manuals.has(recordId)) recordId = `${base}-${suffix++}`;
            if (!sameHash) {
              const record = {...document.record, id: recordId, title: document.record?.title || document.title || document.id, brand: document.record?.brand || 'Local import', type: document.record?.type || 'user-import', models: list(document.record?.models), bytes: blob.size, fileHash: hash, savedAt: Date.now(), imported: true};
              // Only the actual imported hash can identify these bytes.
              if (record.sha256 && record.sha256 !== hash) delete record.sha256;
              put('manuals', record); manuals.set(recordId, record);
            }
            // Reuse the existing document identity while installing verified bytes.
            // This also repairs a stale/corrupt file with a falsely matching record hash.
            put('files', blob, recordId); storedFiles[recordId] = blob;
            candidate.preparation[document.id] = {...candidate.preparation[document.id], recordId, hash, bytes: blob.size, status: 'saved', processorVersion: null, error: null, bytesVerified: true, verification: 'helper-bundle-sha256'};
          }
          const merged = mergeHelperSnapshot(store, candidate);
          put('settings', merged.store, HELPERS_KEY); result(merged.helper);
        };
        if (!files.length) { commit({}); return; }
        const hashes = new Set(files.map(file => file.hash));
        const possible = [...manuals.values()].filter(record => hashes.has(record.fileHash || record.sha256));
        readMany(read, possible.map(record => [record.id, 'files', record.id]), commit);
      });
    });
  }
  return {loadHelpers, saveHelper, updateHelper, renameHelper, saveHelperConversation, deleteHelper, setActiveHelper, exportHelper, exportHelperBundle, importHelper};
}
const defaultStore = createHelpersStore();
export const loadHelpers = (...args) => defaultStore.loadHelpers(...args);
export const saveHelper = (...args) => defaultStore.saveHelper(...args);
export const updateHelper = (...args) => defaultStore.updateHelper(...args);
export const renameHelper = (...args) => defaultStore.renameHelper(...args);
export const saveHelperConversation = (...args) => defaultStore.saveHelperConversation(...args);
export const deleteHelper = (...args) => defaultStore.deleteHelper(...args);
export const setActiveHelper = (...args) => defaultStore.setActiveHelper(...args);
export const exportHelper = (...args) => defaultStore.exportHelper(...args);
export const exportHelperBundle = (...args) => defaultStore.exportHelperBundle(...args);
export const importHelper = (...args) => defaultStore.importHelper(...args);
