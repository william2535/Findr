// Download the pinned pack through the unmodified application worker.
// This is intentionally opt-in; reuse the profile for offline acceptance.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url),{chromium}=require('/opt/codex/cua_node/lib/node_modules/playwright');
const root=path.resolve(import.meta.dirname,'..'),base=process.env.FINDR_QA_URL||'http://127.0.0.1:8088',profile=process.env.FINDR_MODEL_PROFILE||'/tmp/findr032-model-chromium-profile';
const output=path.join(root,'research/helpers-0.32.0/model-preparation.json');
fs.mkdirSync(path.dirname(output),{recursive:true});
const proxyURL=process.env.HTTPS_PROXY?new URL(process.env.HTTPS_PROXY):null;
const context=await chromium.launchPersistentContext(profile,{headless:true,executablePath:'/usr/bin/chromium',serviceWorkers:'block',viewport:{width:390,height:844},args:['--no-sandbox','--disable-dev-shm-usage'],...(proxyURL?{proxy:{server:proxyURL.origin,bypass:'<-loopback>,127.0.0.1,localhost'}}:{})});
const page=await context.newPage(),result={status:'running',profile,modelResponsesSubstituted:false,modelExecuted:false,checks:[],progress:[]};
page.on('console',msg=>{if(msg.type()==='error')console.error(msg.text());});
await page.exposeFunction('recordModelProgress',value=>{result.progress.push(value);if(value.phase!=='download'||value.completed===value.total||value.completed%33554432<8388608)console.log(JSON.stringify(value));});
try{
 await page.goto(base+'/app/');
 result.before=await page.evaluate(async()=>{window.language=await import('./local-language.mjs');return language.getLocalLanguageReadiness();});
 if(!result.before.installed){assert.equal(process.env.FINDR_MODEL_DOWNLOAD,'1','Opt-in is required for the pinned model download.');const start=performance.now();result.prepared=await page.evaluate(()=>language.prepareLocalLanguageResources({onProgress:recordModelProgress}));result.downloadMs=performance.now()-start;}
 result.after=await page.evaluate(()=>language.getLocalLanguageReadiness());assert.equal(result.after.installed,true);result.checks.push('Application worker downloaded and verified the complete pinned model pack');result.status='passed';
}catch(error){result.status='failed';result.error=error.stack;process.exitCode=1;console.error(error.stack);}
finally{fs.writeFileSync(output,JSON.stringify(result,null,2)+'\n');await context.close();console.log(output);}
