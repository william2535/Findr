import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {buildHelperPlan,helperDiscipline,searchHelperScopes} from '../public/app/helpers-catalogue.mjs';

const panels=[
  {id:'alpha-panel',brand:'Alpha',model:'Orbit 2',category:'fire',aliases:['ORB-2'],record_ids:['alpha-install','family']},
  {id:'beta-panel',brand:'Beta',model:'Orbit 2',category:'fire',record_ids:['beta-install']},
  {id:'alpha-other',brand:'Alpha',model:'Orbit 20',category:'fire',record_ids:['other-install']},
  {id:'intruder',brand:'Alpha',model:'Secure 2',category:'security',record_ids:['intruder-install']},
];
const devices=[
  {id:'alpha-detector',brand:'Alpha',model:'Orbit detector',category:'fire',protocol:'Universal loop',part_numbers:['ORB-D'],record_ids:['family','detector-guide']},
  {id:'alpha-base',brand:'Alpha',model:'Orbit base',category:'fire',protocol:'Universal loop',record_ids:['base-guide']},
  {id:'beta-detector',brand:'Beta',model:'Orbit detector',category:'fire',protocol:'Universal loop',record_ids:['beta-guide']},
];
const packs=[{id:'alpha-pack',brand:'Alpha',category:'fire',panel_ids:['alpha-panel','alpha-other'],record_ids:['alpha-install','family','other-install','pack-extra']}];
const devicePacks=[{id:'alpha-device-pack',brand:'Alpha',category:'fire',device_ids:['alpha-detector','alpha-base'],record_ids:['family','detector-guide','base-guide']}];
const records=new Map([
  ['alpha-install',{id:'alpha-install',brand:'Alpha',models:['Orbit 2'],category:'fire',title:'Orbit 2 installation',url:'https://example.test/alpha.pdf',bytes:100,sha256:'alpha-hash',revision:'Issue 2'}],
  ['family',{id:'family',brand:'Alpha',models:['Orbit 2','ORB-D'],category:'fire',title:'Orbit panel and detector instructions',url:'https://example.test/family.pdf',bytes:200,sha256:'family-hash'}],
  ['detector-guide',{id:'detector-guide',brand:'Alpha',models:['ORB-D'],category:'fire',title:'Detector guide',url:'https://example.test/detector.pdf',bytes:50,sha256:'detector-hash'}],
  ...['beta-install','other-install','intruder-install','base-guide','beta-guide','pack-extra'].map(id=>[id,{id,brand:id.startsWith('beta')?'Beta':'Alpha',models:[],title:id,category:id.startsWith('intruder')?'security':'fire',url:'https://example.test/'+id+'.pdf',bytes:30}]),
]);
const context={panels,devices,packs,devicePacks,records,modelState:{ready:true}};
const panelScope=()=>searchHelperScopes({...context,query:'Alpha Orbit 2'}).find(scope=>scope.kind==='panel'&&scope.panelId==='alpha-panel');

test('search keeps identical model names under distinct manufacturers and starts unconfirmed',()=>{
  const matches=searchHelperScopes({...context,query:'Orbit 2',discipline:'Fire'}).filter(scope=>scope.kind==='panel');
  assert.equal(matches.length,3);
  assert.deepEqual(matches.slice(0,2).map(scope=>scope.manufacturer),['Alpha','Beta']);
  assert.ok(matches.every(scope=>scope.confirmed===false));
  const selected=panelScope();
  assert.equal(selected.model,'Orbit 2');
  assert.deepEqual(selected.recordIds,['alpha-install','family']);
  const plan=buildHelperPlan(selected,context);
  assert.ok(!plan.manualIds.includes('beta-install'));
  assert.ok(!plan.manualIds.includes('other-install'));
  assert.ok(!plan.manualIds.includes('pack-extra'));
});

test('discipline filters cover fire, intruder, CCTV, access control and other without mixing',()=>{
  assert.equal(helperDiscipline('security'),'intruder');
  assert.equal(helperDiscipline('AccessControl'),'access-control');
  assert.equal(helperDiscipline('emergency-lighting'),'other');
  const results=searchHelperScopes({...context,discipline:'intruder'});
  assert.ok(results.length>0);
  assert.ok(results.every(scope=>scope.discipline==='intruder'));
  assert.ok(!results.some(scope=>scope.panelId==='alpha-panel'));
});

test('protocol group documents exact recorded members and never establishes compatibility',()=>{
  const groups=searchHelperScopes({...context,query:'Universal loop'}).filter(scope=>scope.kind==='protocol');
  assert.equal(groups.length,2);
  const plan=buildHelperPlan(groups.find(scope=>scope.manufacturer==='Alpha'),context);
  assert.deepEqual(plan.entities.map(entity=>entity.id),['alpha-detector','alpha-base']);
  assert.ok(!plan.manualIds.includes('beta-guide'));
  assert.ok(!plan.manualIds.includes('alpha-install'));
  assert.equal(plan.coverage.compatibilityVerified,false);
  assert.match(plan.unverified.join(' '),/protocol.*does not establish compatibility/i);
});

test('manual co-coverage offers explicit adjacent references but never transitive or pack expansion',()=>{
  const extra={id:'transitive',brand:'Alpha',model:'Other detector',category:'fire',record_ids:['detector-guide','transitive-guide']};
  const plan=buildHelperPlan({...panelScope(),confirmed:true},{...context,devices:[...devices,extra]});
  assert.deepEqual(plan.requiredManualIds,['alpha-install','family']);
  assert.deepEqual(plan.optionalDocs.map(doc=>doc.id),['detector-guide']);
  assert.deepEqual(plan.entities.map(entity=>[entity.id,entity.relation]),[['alpha-panel','selected'],['alpha-detector','shared-manual']]);
  assert.deepEqual(plan.entities[1].evidenceRecordIds,['family']);
  assert.equal(plan.coverage.relation,'documented-manual-coverage');
  assert.match(plan.recommendation,/choose fewer manuals/);
  assert.match(plan.unverified.join(' '),/Shared manuals.*do not establish.*compatible/);
  assert.ok(!plan.manualIds.includes('transitive-guide'));
});

test('manufacturer selection is an explicit broad collection and excludes similarly named manufacturers',()=>{
  const other={id:'alphanumeric',brand:'Alpha Systems',model:'Orbit 2',category:'fire',record_ids:['beta-install']};
  const data={...context,panels:[...panels,other]};
  const scope=searchHelperScopes({...data,query:'Alpha',discipline:'fire'}).find(scope=>scope.kind==='manufacturer'&&scope.manufacturer==='Alpha');
  const plan=buildHelperPlan(scope,data);
  assert.ok(plan.manualIds.includes('other-install'));
  assert.ok(plan.manualIds.includes('pack-extra'));
  assert.ok(!plan.manualIds.includes('beta-install'));
  assert.ok(!plan.manualIds.includes('intruder-install'));
  assert.match(scope.scopeNote,/different systems/);
  assert.equal(plan.coverage.compatibilityVerified,false);
});

test('multi-model documents remain selectable without inferring product compatibility',()=>{
  const scope=searchHelperScopes({...context,query:'ORB-D'}).find(scope=>scope.kind==='document-family');
  assert.equal(scope.documentId,'family');
  const plan=buildHelperPlan(scope,context);
  assert.deepEqual(plan.requiredManualIds,['family']);
  assert.deepEqual(plan.entities.map(entity=>entity.id),['alpha-panel','alpha-detector']);
  assert.ok(plan.optionalDocs.some(doc=>doc.id==='alpha-install'));
  assert.match(scope.scopeNote,/not automatically compatible/);
});

test('saved files and identical hashes are estimated once with honest unknown sizes and shared model costs',()=>{
  const scopedPanel={...panels[0],record_ids:['alpha-install','same-file','unknown','online-only']};
  const scopedRecords=new Map([...records,['same-file',{...records.get('alpha-install'),id:'same-file'}],['unknown',{id:'unknown',title:'Unknown size',url:'https://example.test/unknown.pdf',bytes:null}],['online-only',{id:'online-only',title:'Online only',source:'https://example.test/reference'}]]);
  const savedManuals=new Map([['existing-copy',{id:'existing-copy',fileHash:'alpha-hash',bytes:100}]]);
  const plan=buildHelperPlan({...panelScope(),recordIds:scopedPanel.record_ids},{...context,panels:[scopedPanel],devices:[],records:scopedRecords,savedManuals,modelState:{totalBytes:1000,downloadBytes:400,runtimeReady:true}});
  assert.equal(plan.estimate.fileCount,3);
  assert.equal(plan.estimate.knownBytes,100);
  assert.equal(plan.estimate.savedBytes,100);
  assert.equal(plan.estimate.downloadBytes,0);
  assert.equal(plan.estimate.unknownCount,2);
  assert.equal(plan.estimate.sharedCount,2);
  assert.equal(plan.estimate.modelDownloadBytes,400);
  assert.equal(plan.estimate.totalDownloadBytes,400);
  assert.equal(plan.estimate.hasUnknownBytes,true);
  assert.equal(plan.requiredDocs[0].saved,false,'physical saved alias is not falsely presented as an exact saved record');
  assert.equal(plan.requiredDocs[0].sharedSaved,true);
  assert.equal(plan.requiredDocs[0].savedRecordId,'existing-copy');
  assert.equal(plan.requiredDocs[1].canonicalManualId,'alpha-install');
  assert.equal(plan.requiredDocs.find(doc=>doc.id==='online-only').status,'unavailable');
  assert.ok(plan.missingDocuments.some(issue=>issue.kind==='unavailable-document'));
});

test('known unsaved duplicate hashes count once while exact saved IDs need no extra model download',()=>{
  const scopedPanel={...panels[0],record_ids:['alpha-install','same-file','family']};
  const scopedRecords=new Map([...records,['same-file',{...records.get('alpha-install'),id:'same-file'}]]);
  const plan=buildHelperPlan(panelScope(),{...context,panels:[scopedPanel],devices:[],records:scopedRecords,savedManuals:new Set(['family'])});
  assert.equal(plan.estimate.knownBytes,300);
  assert.equal(plan.estimate.downloadBytes,100);
  assert.equal(plan.estimate.savedBytes,200);
  assert.equal(plan.estimate.modelDownloadBytes,0);
  assert.equal(plan.estimate.runtimeDownloadBytes,0);
  assert.equal(plan.documents.find(doc=>doc.id==='family').status,'saved');
});

test('a saved ID with a conflicting known hash does not hide the replacement download',()=>{
  const plan=buildHelperPlan(panelScope(),{...context,savedManuals:new Map([['alpha-install',{id:'alpha-install',fileHash:'wrong-hash',bytes:900}]])});
  const document=plan.documents.find(doc=>doc.id==='alpha-install');
  assert.equal(document.saved,false);
  assert.equal(document.bytes,100);
  assert.equal(document.savedRecordId,null);
  assert.match(plan.unverified.join(' '),/different file hash/);
  assert.equal(plan.estimate.downloadBytes,350);
});

test('missing linked records and unknown scopes stay visible rather than falling back to similar products',()=>{
  const plan=buildHelperPlan(panelScope(),{...context,panels:[{...panels[0],record_ids:['missing']}]});
  assert.deepEqual(plan.requiredManualIds,['missing']);
  assert.equal(plan.documents.length,0);
  assert.equal(plan.missingDocuments[0].kind,'missing-record');
  for(const altered of [{panelId:'not-present'},{manufacturer:'Beta'},{model:'Orbit 20'}]){
    const rejected=buildHelperPlan({...panelScope(),...altered},context);
    assert.equal(rejected.manualIds.length,0);
    assert.ok(rejected.missingDocuments.length>0);
  }
});

test('live catalogue plans keep Gent and Advanced scope IDs separate and only use explicit links',()=>{
  const read=name=>JSON.parse(readFileSync(new URL(`../public/app/data/${name}.json`,import.meta.url),'utf8'));
  const live={panels:read('panels'),devices:read('devices'),packs:read('packs'),devicePacks:read('device-packs'),records:[...read('catalogue').records,...read('device-documents')],modelState:{ready:true}};
  for(const query of ['Gent Vigilon Compact','Advanced MxPro 5']){
    const scopes=searchHelperScopes({...live,query});
    const scope=scopes.find(scope=>scope.kind==='panel');
    assert.ok(scope,query);
    const plan=buildHelperPlan(scope,live);
    const panel=live.panels.find(panel=>panel.id===scope.panelId);
    assert.deepEqual(plan.requiredManualIds,panel.record_ids);
    assert.ok(plan.entities.every(entity=>entity.manufacturer===scope.manufacturer));
    assert.equal(plan.coverage.compatibilityVerified,false);
  }
});
