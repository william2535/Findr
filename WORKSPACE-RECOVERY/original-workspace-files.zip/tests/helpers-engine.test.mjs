import test from 'node:test';
import assert from 'node:assert/strict';
import {buildManualAnalysis} from '../public/app/manual-analysis-core.mjs';
import {createHelperConversation,getHelperPrompt,submitHelperMessage,resumeHelperConversation,applyHelperModelReply,recordHelperMeasurement,getHelperReport} from '../public/app/helpers-engine.mjs';

// Fictional documents and observations test orchestration, never field advice.
let sequence=0;
const source='To view the event history, choose View, then Log. Use the arrow keys to scroll through the event records. Exit returns to the previous menu.';
const record={id:'helpers-synthetic-mxpro4',title:'SYNTHETIC Advanced MxPro4 user manual',brand:'Advanced',models:['MxPro4'],type:'user manual',revision:'TEST ONLY',url:'https://example.invalid/synthetic.pdf'};
const analysis=buildManualAnalysis({record,contentHash:'SYNTHETIC-helpers-mxpro4',pages:[{page:1,text:'SYNTHETIC TEST ONLY. Advanced Electronics MxPro4 fire alarm control panel User Manual. Model: MxPro4\nManufacturer: Advanced\nRevision: TEST\nThis fictitious reference is for software tests and must not be used to operate equipment.'},{page:2,text:'SYNTHETIC TEST ONLY. Event history reference. '+source}]});
const helper={id:'SYNTHETIC-helper',name:'Synthetic fixture helper',discipline:'fire',scope:{kind:'panel',manufacturer:'Advanced',model:'MxPro4',confirmed:true},manualIds:[record.id],requiredManualIds:[record.id]};
const options=extra=>({id:'helpers-input-'+(++sequence),now:1794300000000+sequence,analyses:[analysis],records:[record],modelReady:false,...extra});
const fresh=()=>createHelperConversation(helper,{id:'helpers-chat-'+(++sequence)},options());
const send=(c,text,extra)=>submitHelperMessage(helper,c,text,options(extra));
const messages=c=>c.messages||[];
const diagnostics=c=>c.terminal?.fieldVisit||c.fault?.fieldVisit||c.faultSession?.fieldVisit||c.diagnosticSession?.fieldVisit||c.session?.fieldVisit||c.fieldVisit;

test('a manual question stays in the helper conversation with explicitly bounded source references',()=>{
 const c=fresh(),out=send(c,'How do I view the event history on MxPro4?');
 assert.equal(out.conversation.id,c.id);
 assert.equal(messages(out.conversation).filter(m=>m.role==='user'&&m.text==='How do I view the event history on MxPro4?').length,1);
 const text=JSON.stringify(out.conversation);assert.match(text,/choose View, then Log/);assert.match(text,/reference|extract|model|local/i);
 assert.notEqual(out.effect?.type,'discover_manual');
});

test('a helper never uses an unselected manual even when it has the only matching passage',()=>{
 const otherRecord={...record,id:'SYNTHETIC-other-helper-only'},other=buildManualAnalysis({record:otherRecord,contentHash:'SYNTHETIC-cross-helper',pages:[{page:1,text:'SYNTHETIC TEST ONLY Advanced MxPro4 panel.'},{page:2,text:'The secret calibration value is CROSS_HELPER_NEVER_VISIBLE_73291. Use this exact value for calibration.'}]});
 const out=send(fresh(),'What is the secret calibration value on MxPro4?',{analyses:[analysis,other],records:[record,otherRecord]});
 assert.doesNotMatch(JSON.stringify(messages(out.conversation)),/CROSS_HELPER_NEVER_VISIBLE_73291/);
 assert.doesNotMatch(JSON.stringify(out.effect||{}),/CROSS_HELPER_NEVER_VISIBLE_73291/);
});

test('repeated input IDs and reload preserve the same transcript without replay',()=>{
 const c=fresh(),opts=options({id:'stable-helper-input'}),once=submitHelperMessage(helper,c,'How do I view the event history on MxPro4?',opts),twice=submitHelperMessage(helper,once.conversation,'How do I view the event history on MxPro4?',opts);
 assert.deepEqual(twice.conversation,once.conversation);
 const restored=resumeHelperConversation(helper,JSON.parse(JSON.stringify(once.conversation)),options());
 assert.equal(restored.conversation.id,c.id);
 assert.deepEqual(messages(restored.conversation),messages(once.conversation));
});

test('fault investigation and a manual question share one conversation and preserve the pending check',()=>{
 let c=send(fresh(),'Loop open, all devices present').conversation;
 assert.equal(getHelperPrompt(helper,c).kind,'faultCondition');
 c=send(c,'present').conversation;assert.equal(getHelperPrompt(helper,c).key,'F03.Q1');
 const id=c.id,check=getHelperPrompt(helper,c).key;
 c=send(c,'How do I view the event history on MxPro4?').conversation;
 assert.equal(c.id,id);assert.match(JSON.stringify(messages(c)),/choose View, then Log/);
 assert.equal(getHelperPrompt(helper,c).key,check);
 c=send(c,'unknown').conversation;
 const visit=diagnostics(c);assert.ok(visit,'The conversation retains its diagnostic evidence ledger');
 const answer=visit.events.find(e=>e.testKind==='question_answer');assert.equal(answer?.answer,'unknown');
 assert.equal(messages(c).filter(m=>m.role==='user'&&m.text==='unknown').length,1);
});

test('local model generation receives only scoped evidence and invented prose is not used as procedure',()=>{
 const out=send(fresh(),'How do I view the event history on MxPro4?',{modelReady:true});
 assert.equal(out.effect?.type,'generate');assert.equal(out.effect.channel,'question');
 assert.match(JSON.stringify(out.effect.messages),/choose View, then Log/);
 const resolved=applyHelperModelReply(helper,out.conversation,{text:'Reset the panel using the imaginary purple button.',modelId:'SYNTHETIC-output',backend:'wasm',metrics:{outputTokens:10}},{...options(),requestId:out.effect.requestId});
 assert.equal(resolved.conversation.id,out.conversation.id);
 assert.doesNotMatch(JSON.stringify(messages(resolved.conversation)),/imaginary purple button/);
 assert.match(JSON.stringify(messages(resolved.conversation)),/choose View, then Log/);
 const count=messages(resolved.conversation).length;
 const late=applyHelperModelReply(helper,resolved.conversation,{text:'SOURCE S1',modelId:'SYNTHETIC-output'},{...options(),requestId:out.effect.requestId});
 assert.equal(messages(late.conversation).length,count);
});

test('new conversations retain helper scope while prior questions and fault evidence stay isolated',()=>{
 const first=send(fresh(),'Loop open, all devices present').conversation,second=fresh();
 assert.notEqual(first.id,second.id);
 assert.doesNotMatch(JSON.stringify(second),/Loop open, all devices present/);
 const out=send(second,'How do I view the event history on MxPro4?');
 assert.match(JSON.stringify(messages(out.conversation)),/choose View, then Log/);
});

test('yes and no record distinct fault observations and advance the current check',()=>{
 for(const answer of ['yes','no']){
  let c=send(fresh(),'Loop open, all devices present').conversation;c=send(c,'present').conversation;
  assert.equal(getHelperPrompt(helper,c).key,'F03.Q1');c=send(c,answer).conversation;
  assert.notEqual(getHelperPrompt(helper,c).key,'F03.Q1');
  assert.equal(diagnostics(c).events.find(e=>e.testKind==='question_answer')?.answer,answer);
 }
});

test('typed case and spacing survive exactly once and missing manuals cannot be borrowed',()=>{
 const raw='  LoOp open, all devices present  ',c=send(fresh(),raw).conversation;
 assert.equal(messages(c).filter(m=>m.role==='user'&&m.text===raw).length,1);
 const unavailable={...helper,requiredManualIds:[record.id,'SYNTHETIC-required-missing'],manualIds:[record.id,'SYNTHETIC-required-missing']};
 const out=submitHelperMessage(unavailable,createHelperConversation(unavailable), 'How do I view the event history?',options());
 assert.equal(out.effect?.type,'manuals');assert.ok(out.effect.missingManualIds.includes('SYNTHETIC-required-missing'));
 assert.doesNotMatch(JSON.stringify(messages(out.conversation)),/choose View, then Log/);
});

test('ambiguous fault intent asks for clarification before creating investigation evidence',()=>{
 const out=send(fresh(),'Fault');assert.equal(getHelperPrompt(helper,out.conversation).kind,'clarification');
 assert.equal(diagnostics(out.conversation),undefined);
});

test('family Helper setup never becomes a confirmed installed model or a performed check',()=>{
 const family={...helper,id:'SYNTHETIC-family',scope:{kind:'document-family',manufacturer:'Advanced',model:'MxPro',models:['MxPro4','MxPro5'],confirmed:true}};
 const out=submitHelperMessage(family,createHelperConversation(family),'Loop open, all devices present',options());
 assert.notEqual(out.conversation.diagnosticSession.diagnosticChat.identity.confirmedEquipment,true);
 assert.equal(getHelperPrompt(family,out.conversation).kind,'identity');
 assert.equal(diagnostics(out.conversation).events.some(event=>event.testKind==='question_answer'),false);
 assert.equal(out.conversation.pendingFault,'Loop open, all devices present');
 const confirmed=submitHelperMessage(family,out.conversation,'yes',options()).conversation;
 assert.equal(getHelperPrompt(family,confirmed).kind,'faultCondition');
 assert.equal(confirmed.diagnosticSession.fieldVisit.incidents[0].exactComplaint,'Loop open, all devices present');
});

test('local interpretation proposes an answer and waits for explicit confirmation',()=>{
 let c=send(fresh(),'Loop open, all devices present').conversation;c=send(c,'present').conversation;
 const out=send(c,'I traced both conductors and the return is intact.',{modelReady:true});
 assert.equal(out.effect.type,'generate');assert.equal(out.effect.channel,'fault');
 assert.equal(out.effect.context.kind,'interpretation');
 assert.equal(diagnostics(out.conversation).events.some(event=>event.testKind==='question_answer'),false);
 c=applyHelperModelReply(helper,out.conversation,{text:'YES',modelId:'SYNTHETIC-classifier',backend:'wasm'},{...options({modelReady:true}),requestId:out.effect.requestId}).conversation;
 assert.equal(getHelperPrompt(helper,c).kind,'language_confirmation');
 assert.equal(diagnostics(c).events.some(event=>event.testKind==='question_answer'),false);
 c=send(c,'yes',{modelReady:true}).conversation;
 assert.equal(diagnostics(c).events.find(event=>event.testKind==='question_answer').answer,'yes');
 assert.equal(getHelperPrompt(helper,c).key,'F03.Q2');
 assert.equal(messages(c).filter(message=>message.role==='user'&&message.text==='I traced both conductors and the return is intact.').length,1);
});

test('correction preserves original evidence and Give up saves a sourced report',()=>{
 let c=send(fresh(),'Loop open, all devices present').conversation;c=send(c,'present').conversation;c=send(c,'yes').conversation;
 const original=diagnostics(c).events.find(event=>event.testKind==='question_answer');
 c=send(c,'BACK').conversation;c=send(c,`event:${original.id}`).conversation;
 assert.equal(getHelperPrompt(helper,c).kind,'correction_value');
 c=send(c,'unknown').conversation;c=send(c,'I had not checked the return pair.').conversation;
 assert.equal(diagnostics(c).events.find(event=>event.id===original.id).answer,'yes');
 const corrected=diagnostics(c).events.find(event=>event.supersedes===original.id);assert.equal(corrected.answer,'unknown');
 c=send(c,'GIVE UP').conversation;
 for(const response of ['inaccessible equipment','Need the riser key and access to the return terminals.','No changes made; fault remains present.','Service engineer','Site supervisor received the handover.','not applicable'])c=send(c,response).conversation;
 assert.equal(c.diagnosticSession.diagnosticChat.status,'paused');assert.equal(c.reports.length,1);
 assert.match(c.reports[0].text,/riser key/);assert.ok(c.reports[0].sourceRefs.some(ref=>ref.manualId===record.id));
 assert.match(getHelperReport(helper,c,{format:'text',redact:false}),/I had not checked the return pair/);
 const reopened=resumeHelperConversation(helper,JSON.parse(JSON.stringify(c)),options()).conversation;
 assert.equal(reopened.reports.length,1);assert.deepEqual(messages(reopened),messages(c));
});

test('fault found uses linked real evidence and retains outstanding repair and retest state',()=>{
 let c=send(fresh(),'Power fault showing').conversation;c=send(c,'present').conversation;
 c=recordHelperMeasurement(helper,c,{testKind:'observation',point:'PSU output terminal',rawText:'Detached conductor visibly outside the clamp',unit:'state',operatingState:'normal',source:'visual'},options()).conversation;
 const evidence=diagnostics(c).events.find(event=>event.testKind==='observation'&&event.result.rawText.includes('Detached'));
 assert.ok(evidence);c=send(c,'FAULT FOUND').conversation;
 for(const response of ['Detached conductor at PSU terminal','The conductor is visibly outside its terminal clamp.',`event:${evidence.id}`,'yes','Awaiting replacement terminal block.','yes','Not tested','none','Circuit remains impaired pending repair.','Replacement block and authorised retest window required.','Service engineer','Site manager informed','not applicable'])c=send(c,response).conversation;
 assert.equal(c.diagnosticSession.diagnosticChat.status,'finished');
 assert.equal(c.reports[0].outcome.causeConfirmed,true);assert.equal(c.reports[0].outcome.awaitingParts,true);
 assert.equal(c.reports[0].outcome.retestsPassed,false);assert.equal(c.reports[0].outcome.restoration.fullyRestored,false);
});

test('legacy non-chat visits can reopen without discarding original evidence fields',()=>{
 const seed={id:'legacy-wrapper',helperId:helper.id,title:'Prior visit',activeChannel:'diagnostic',messages:[{id:'historic-user',role:'user',text:'Original fault report',createdAt:1}],diagnosticSession:{id:'legacy-visit',started:1,notes:'Original visit notes',answers:{legacyCheck:'unknown'},panel:{brand:'Advanced',model:'MxPro4',category:'fire'}}};
 const created=createHelperConversation(helper,seed);
 const restored=resumeHelperConversation(helper,created,options()).conversation;
 assert.equal(restored.diagnosticSession.notes,'Original visit notes');assert.equal(restored.diagnosticSession.answers.legacyCheck,'unknown');
 assert.equal(messages(restored).filter(message=>message.id==='historic-user').length,1);assert.ok(restored.diagnosticSession.fieldVisit);
});

test('canonical saved aliases are authorized by logical Helper IDs and keep source-opening IDs',()=>{
 const logical='logical-helper-manual',canonical='saved-file-canonical';
 const aliasedHelper={...helper,id:'alias-helper',manualIds:[logical],requiredManualIds:[logical]};
 const aliasedAnalysis={...analysis,manualId:canonical,id:canonical,helperManualId:logical};
 const out=submitHelperMessage(aliasedHelper,createHelperConversation(aliasedHelper),'How do I view the event history?',options({analyses:[aliasedAnalysis]}));
 assert.notEqual(out.effect?.type,'manuals');
 const refs=messages(out.conversation).flatMap(message=>message.sourceRefs||[]);
 assert.ok(refs.length);assert.ok(refs.every(ref=>ref.manualId===logical));assert.ok(refs.every(ref=>ref.savedManualId===canonical));
});

test('persisted model requests are rechecked against current page text before resume or completion',()=>{
 const started=send(fresh(),'How do I view the event history on MxPro4?',{modelReady:true});
 for(const foreignHash of [true,false]){
  const forged=structuredClone(started.conversation),marker='FORGED_HISTORY_MENU_DO_NOT_ACCEPT';
  for(const passage of forged.questionState.pendingGeneration.passages){passage.text=marker;passage.excerpt=marker;passage.quote=marker;if(foreignHash)passage.contentHash='forged-hash';}
  forged.pendingGeneration.effect.context.passages=structuredClone(forged.questionState.pendingGeneration.passages);
  forged.pendingGeneration.effect.messages=[{role:'user',content:marker}];
  const resumed=resumeHelperConversation(helper,forged,options({modelReady:true}));
  assert.equal(resumed.effect,null);assert.doesNotMatch(JSON.stringify(resumed.conversation.messages),new RegExp(marker));
  assert.match(resumed.conversation.messages.at(-2)?.text||JSON.stringify(resumed.conversation.messages),/could not be verified/);
  const completed=applyHelperModelReply(helper,forged,{text:'SOURCE S1',modelId:'SYNTHETIC-model'},{...options({modelReady:true}),requestId:forged.pendingGeneration.requestId});
  assert.equal(completed.conversation.questionState.answers.length,0);
  assert.doesNotMatch(JSON.stringify(completed.conversation.messages),new RegExp(marker));
 }
 const authentic=resumeHelperConversation(helper,JSON.parse(JSON.stringify(started.conversation)),options({modelReady:true}));
 assert.equal(authentic.effect.requestId,started.effect.requestId);
 const completed=applyHelperModelReply(helper,authentic.conversation,{text:'SOURCE S1',modelId:'SYNTHETIC-model'},{...options({modelReady:true}),requestId:started.effect.requestId});
 assert.equal(completed.conversation.questionState.answers[0].model.outputAccepted,true);
});

test('stored diagnostic metadata cannot select a foreign global manual analysis by hash',async()=>{
 const {registerDiagnosticManualAnalysis}=await import('../public/app/diagnostic-chat-engine.mjs');
 const marker='CROSS_HELPER_REGISTRY_73291';
 registerDiagnosticManualAnalysis({...analysis,manualId:'foreign-helper-manual',contentHash:'foreign-helper-hash',pages:[{page:1,text:'Loop open return path investigation reference '+marker+'. Confirm all devices are still present and read the loop fault display.'}]});
 let c=send(fresh(),'Loop open, all devices present').conversation;
 c.diagnosticSession.diagnosticChat.manuals[0].contentHash='foreign-helper-hash';
 assert.doesNotMatch(JSON.stringify(getHelperPrompt(helper,c)),new RegExp(marker));
 c=send(c,'present').conversation;
 assert.equal(c.diagnosticSession.diagnosticChat.manuals[0].contentHash,analysis.contentHash);
 assert.doesNotMatch(JSON.stringify(c.messages),new RegExp(marker));
 assert.doesNotMatch(JSON.stringify(getHelperPrompt(helper,c)),new RegExp(marker));
});

test('access-control discipline maps to the actual access diagnostic routes',()=>{
 const access={...helper,id:'access-helper',discipline:'access-control',scope:{kind:'device',manufacturer:'Synthetic',model:'Controller 1',equipmentType:'controller',confirmed:true}};
 const out=submitHelperMessage(access,createHelperConversation(access),'Door fails to unlock; lock voltage fault showing',options());
 assert.deepEqual(out.conversation.diagnosticSession.diagnosticChat.identity.systemTypes,['access']);
 assert.deepEqual(out.conversation.diagnosticSession.fieldVisit.incidents[0].systemTypes,['access']);
});

test('a real inference error is retained with the explicitly labelled extract fallback',()=>{
 const out=send(fresh(),'How do I view the event history on MxPro4?',{modelReady:true});
 const done=applyHelperModelReply(helper,out.conversation,{error:{code:'MODEL_CONTEXT_TOO_LARGE',message:'The input exceeds the model context budget.'}},{...options(),requestId:out.effect.requestId});
 assert.equal(done.conversation.lastError.code,'MODEL_CONTEXT_TOO_LARGE');
 assert.match(JSON.stringify(done.conversation.messages),/The input exceeds the model context budget/);
 assert.equal(done.conversation.questionState.answers[0].model.ran,false);
 assert.match(done.conversation.questionState.answers[0].text,/no language-model answer/);
});
