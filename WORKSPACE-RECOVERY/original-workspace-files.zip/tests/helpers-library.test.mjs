import test from 'node:test';
import assert from 'node:assert/strict';
import {createHelperLibrary} from '../public/app/helpers-library.mjs';
import {validatePDF} from '../public/app/engine.mjs';
import {MANUAL_ANALYSIS_VERSION} from '../public/app/manual-analysis.mjs';
import {loadQuickManualIndex} from '../public/app/retrieval-cache.mjs';

const pageText='The fire control panel records the complete event history. Open the event menu to review the dated events and their addresses. Confirm the installed panel model before using this manual as a reference.';
const pdf=id=>new Blob([`%PDF-1.4\n1 0 obj << /Type /Catalog /Name (${id}) >> endobj\ntrailer << /Root 1 0 R >>\n%%EOF`],{type:'application/pdf'});
const helper=(manualIds=['a','b'],extra={})=>({id:'helper-one',name:'Site equipment',scope:{system:'fire'},manualIds,requiredManualIds:[manualIds[0]],preparation:{},...extra});
async function fixture(names=['a','b','c']){
 const records=new Map(),files=new Map(),saved=new Map(),analyses=new Map(),settings=new Map(),snapshots=[],downloads=[],processed=[],progress=[];
 for(const id of names){const blob=pdf(id),sha256=await validatePDF(blob);records.set(id,{id,title:`Manual ${id}`,url:`/manual/${id}.pdf`,sha256,bytes:blob.size});}
 const state={model:{supported:true,ready:true,installed:true,runtimeReady:true,status:'ready',model:{bytes:1000},downloadBytes:0,files:[{savedBytes:1000}]},processing:{supported:true,ready:true,downloadBytes:0},shell:true,quota:{usage:0,quota:1e8},fail:new Set(),unreadable:new Set(),failIndex:false};
 const read=async key=>settings.get(key),write=async(key,value)=>{if(state.failIndex)throw Object.assign(Error('The index could not be saved.'),{code:'STORAGE_UNAVAILABLE'});settings.set(key,structuredClone(value));};
 const makeAnalysis=(id,hash)=>({schemaVersion:1,processorVersion:MANUAL_ANALYSIS_VERSION,contentHash:hash,manualId:id,title:`Manual ${id}`,usable:!state.unreadable.has(id),pageCount:1,pages:[{page:1,text:state.unreadable.has(id)?'Unreadable':pageText,method:'text',quality:{readable:!state.unreadable.has(id)}}]});
 const save=async(id,recordId=id)=>{const record={...records.get(id),id:recordId,fileHash:records.get(id).sha256};saved.set(recordId,record);files.set(recordId,pdf(id));return record;};
 const index=async id=>{const record=saved.get(id),analysis=makeAnalysis(id,record.fileHash);analyses.set(analysis.contentHash,analysis);await loadQuickManualIndex(analysis,{read,write});return analysis;};
 const options={getRecords:()=>records,getSaved:()=>saved,refreshSaved:async()=>{},getFile:async id=>files.get(id),allManuals:async()=>[...saved.values()],getOfflineReady:()=>state.shell,onUpdateHelper:async value=>{snapshots.push(structuredClone(value));},storageEstimate:async()=>state.quota,
  getLocalLanguageReadiness:async()=>state.model,prepareLocalLanguageResources:async()=>{state.model={...state.model,ready:true,installed:true,downloadBytes:0};return state.model;},getManualProcessingReadiness:async()=>state.processing,downloadManualProcessingResources:async()=>state.processing,
  getManualAnalysis:async hash=>analyses.get(hash),readSetting:read,loadQuickManualIndex:(analysis,options)=>loadQuickManualIndex(analysis,{read,write,...options}),
  downloadManual:async(id,{signal,onProgress})=>{downloads.push(id);onProgress?.({completed:20,total:records.get(id).bytes,message:'Received actual PDF bytes.'});if(signal?.aborted)throw new DOMException('Cancelled','AbortError');if(state.fail.has(id))throw Object.assign(Error('Publisher unavailable.'),{code:'MANUAL_DOWNLOAD_FAILED'});return save(id);},
  analyseManual:async({blob,record,signal,onProgress})=>{processed.push(record.id);onProgress?.({phase:'text',completed:0,total:1,page:1});if(signal?.aborted)throw new DOMException('Cancelled','AbortError');const analysis=makeAnalysis(record.id,await validatePDF(blob));analyses.set(analysis.contentHash,analysis);onProgress?.({phase:'indexing',completed:1,total:1});return analysis;}};
 return {records,files,saved,analyses,settings,snapshots,downloads,processed,progress,state,options,save,index,library:createHelperLibrary(options)};
}

test('a cancelled partial queue persists completed work and resumes in a new library instance',async()=>{
 const f=await fixture(),controller=new AbortController();
 const first=await f.library.prepare(helper(['a','b']),{signal:controller.signal,onProgress:value=>{f.progress.push(value);if(value.phase==='manual-complete'&&value.manualId==='a')controller.abort();}});
 assert.equal(first.cancelled,true);assert.deepEqual(f.downloads,['a']);assert.equal(first.helper.preparation.a.status,'ready');assert.equal(first.helper.preparation.b.status,'cancelled');assert.equal(first.readiness.ready,false);
 assert.equal(f.snapshots.at(-1).preparationState,'cancelled');assert.ok(f.snapshots.some(snapshot=>snapshot.preparation.a.progress?.completed===20));
 const restart=createHelperLibrary(f.options),second=await restart.prepare(f.snapshots.at(-1));
 assert.equal(second.cancelled,false);assert.equal(second.readiness.state,'Ready offline');assert.deepEqual(f.downloads,['a','b']);assert.deepEqual(f.processed,['a','b']);assert.equal(f.files.size,2);
});

test('stale processing metadata after an app restart resumes from saved PDF bytes',async()=>{
 const f=await fixture();await f.save('a');const interrupted=helper(['a'],{preparationState:'preparing',preparation:{a:{status:'processing',recordId:'a'}}});
 assert.equal((await f.library.readiness(interrupted)).state,'Missing manuals');
 const result=await f.library.prepare(interrupted);assert.equal(result.readiness.ready,true);assert.deepEqual(f.downloads,[]);assert.deepEqual(f.processed,['a']);
});

test('quota preflight uses available browser storage and keeps a visible failure',async()=>{
 const f=await fixture();f.state.quota={usage:950,quota:1000};
 const result=await f.library.prepare(helper(['a','b']));
 assert.equal(result.readiness.ready,false);assert.equal(result.helper.preparationError.code,'STORAGE_UNAVAILABLE');assert.match(result.helper.preparationError.message,/storage/);assert.deepEqual(f.downloads,[]);assert.equal(result.errors[0].stage,'preparation');assert.notEqual(result.helper.preparation.a.status,'ready');
});

test('unknown quota does not invent a small device limit',async()=>{
 const f=await fixture();f.state.quota=undefined;
 const result=await f.library.prepare(helper(['a']));assert.equal(result.readiness.ready,true);assert.deepEqual(f.downloads,['a']);
});

test('a failed optional selected manual prevents ready while the remaining queue continues',async()=>{
 const f=await fixture();f.state.fail.add('b');
 const result=await f.library.prepare(helper(['a','b','c']));
 assert.deepEqual(f.downloads,['a','b','c']);assert.equal(result.helper.preparation.a.status,'ready');assert.equal(result.helper.preparation.b.status,'error');assert.equal(result.helper.preparation.c.status,'ready');assert.equal(result.readiness.state,'Missing manuals');assert.deepEqual(result.readiness.missingManualIds,['b']);
 f.state.fail.delete('b');const retry=await f.library.prepare(result.helper);assert.equal(retry.readiness.ready,true);assert.deepEqual(f.downloads,['a','b','c','b']);
});

test('unreadable extraction is isolated and never reported as a prepared manual',async()=>{
 const f=await fixture();f.state.unreadable.add('a');const result=await f.library.prepare(helper(['a','b']));
 assert.equal(result.readiness.ready,false);assert.equal(result.helper.preparation.a.error.code,'UNREADABLE_MANUAL');assert.equal(result.helper.preparation.b.status,'ready');assert.deepEqual(f.processed,['a','b']);assert.ok(f.files.has('a'));assert.equal((await f.library.loadHelperAnalyses(result.helper)).length,1);
});

test('identical PDFs reuse one saved record and one shared index without downloading aliases',async()=>{
 const f=await fixture();await f.save('a','canonical-a');f.records.set('b',{...f.records.get('a'),id:'b',title:'The same checked PDF'});
 const result=await f.library.prepare(helper(['a','b']));
 assert.equal(result.readiness.ready,true);assert.deepEqual(f.downloads,[]);assert.deepEqual(f.processed,['canonical-a']);assert.equal(f.files.size,1);assert.equal(f.settings.size,1);assert.equal(result.helper.preparation.a.recordId,'canonical-a');assert.equal(result.helper.preparation.b.recordId,'canonical-a');
 assert.equal(result.readiness.storage.manualBytes,pdf('a').size);assert.equal(result.readiness.storage.uniqueManuals,1);assert.equal(result.readiness.storage.engineBytes,1000);
 const analyses=await f.library.loadHelperAnalyses(result.helper);assert.equal(analyses.length,1);assert.equal(analyses[0].manualId,'canonical-a');assert.deepEqual(analyses[0].helperManualIds,['a','b']);assert.equal(analyses[0].index.passages[0].manualId,'canonical-a');
});

test('claimed ready metadata and saved rows cannot make corrupt or missing PDF bytes ready',async()=>{
 const f=await fixture();await f.save('a');await f.index('a');const prepared=helper(['a'],{preparation:{a:{status:'ready',hash:f.records.get('a').sha256,processorVersion:MANUAL_ANALYSIS_VERSION}}});
 assert.equal((await f.library.readiness(prepared)).ready,true);f.files.set('a',new Blob(['This is an HTML failure, not a valid PDF document.']));
 assert.equal((await f.library.readiness(prepared)).ready,false);assert.deepEqual(await f.library.loadHelperAnalyses(prepared),[]);f.files.delete('a');assert.equal((await f.library.readiness(prepared)).state,'Missing manuals');
});

test('model, runtime and shell each independently gate Ready offline',async()=>{
 const f=await fixture();await f.save('a');await f.index('a');const selected=helper(['a']);
 f.state.model={...f.state.model,installed:false,ready:false,downloadBytes:1000};let status=await f.library.readiness(selected);assert.equal(status.state,'AI unavailable');assert.equal(status.storage.engineAdditionalBytes,1000);
 f.state.model={...f.state.model,installed:true,ready:true,downloadBytes:0};f.state.processing={...f.state.processing,ready:false};assert.equal((await f.library.readiness(selected)).state,'AI unavailable');
 f.state.processing.ready=true;f.state.shell=false;assert.equal((await f.library.readiness(selected)).ready,false);f.state.shell=true;f.state.model.lastRuntimeError={message:'The model crashed.'};assert.equal((await f.library.readiness(selected)).ready,false);
});

test('a search index must be persisted and checked against readable source pages',async()=>{
 const f=await fixture();f.state.failIndex=true;const result=await f.library.prepare(helper(['a']));assert.equal(result.readiness.ready,false);assert.equal(result.helper.preparation.a.error.code,'STORAGE_UNAVAILABLE');
 f.state.failIndex=false;const retry=await f.library.prepare(result.helper);assert.equal(retry.readiness.ready,true);assert.deepEqual(f.processed,['a']);
 const key=[...f.settings.keys()][0],index=f.settings.get(key);index.passages[0].text='Invented passage missing from the saved PDF analysis.';f.settings.set(key,index);
 assert.equal((await f.library.readiness(retry.helper)).ready,false);assert.equal(f.settings.get(key).passages[0].text,'Invented passage missing from the saved PDF analysis.');
});

test('scoped analysis loads exclude other globally saved manuals and out-of-scope required IDs',async()=>{
 const f=await fixture();for(const id of ['a','b','c']){await f.save(id);await f.index(id);}
 const values=await f.library.loadHelperAnalyses(helper(['b']));assert.deepEqual(values.map(value=>value.helperManualId),['b']);assert.equal(values[0].index.passages[0].manualId,'b');
 const invalid=helper(['a'],{requiredManualIds:['c']});assert.equal((await f.library.readiness(invalid)).ready,false);assert.deepEqual((await f.library.loadHelperAnalyses(invalid)).map(value=>value.helperManualId),['a']);await assert.rejects(f.library.prepare(invalid),{code:'HELPER_SCOPE_INVALID'});
});

test('storage persistence failure does not become completion or leave a running operation',async()=>{
 const f=await fixture(),library=createHelperLibrary({...f.options,onUpdateHelper:async()=>{throw new Error('Settings write failed.');}});
 await assert.rejects(library.prepare(helper(['a'])),/Settings write failed/);assert.equal(library.isPreparing('helper-one'),false);assert.deepEqual(f.downloads,[]);
});

test('the returned helper retains metadata and conversation changes committed during preparation',async()=>{
 const f=await fixture(),library=createHelperLibrary({...f.options,onUpdateHelper:async value=>({...value,name:'Renamed during preparation',conversations:[{id:'new-conversation',messages:[{id:'kept',text:'A saved note.'}]}]})});
 const result=await library.prepare(helper(['a']));assert.equal(result.helper.name,'Renamed during preparation');assert.equal(result.helper.conversations[0].messages[0].text,'A saved note.');assert.equal(result.helper.preparation.a.status,'ready');
});

test('valid PDF bytes from another edition cannot satisfy an archive hash',async()=>{
 const f=await fixture();await f.save('a');await f.index('a');f.files.set('a',pdf('another-edition'));
 const status=await f.library.readiness(helper(['a']));assert.equal(status.ready,false);assert.equal(status.documents[0].status,'error');assert.deepEqual(await f.library.loadHelperAnalyses(helper(['a'])),[]);
});

test('cancelling an active helper prevents a second concurrent queue and releases its slot',async()=>{
 const f=await fixture();let release,entered;const started=new Promise(resolve=>{entered=resolve;});const pending=new Promise(resolve=>{release=resolve;});
 const library=createHelperLibrary({...f.options,downloadManual:async(id,options)=>{entered();await pending;if(options.signal.aborted)throw new DOMException('Cancelled','AbortError');return f.options.downloadManual(id,options);}});
 const running=library.prepare(helper(['a']));await started;assert.equal(library.isPreparing('helper-one'),true);assert.equal((await library.readiness(helper(['a']))).state,'Preparing');await assert.rejects(library.prepare(helper(['a'])),{code:'HELPER_BUSY'});library.cancel('helper-one');release();const result=await running;assert.equal(result.cancelled,true);assert.equal(library.isPreparing('helper-one'),false);
});

test('unchecked preparation aliases cannot read another globally saved PDF',async()=>{
 const f=await fixture();await f.save('b');await f.index('b');
 for(const preparation of [{recordId:'b',status:'ready'},{recordId:'b',hash:f.records.get('b').sha256,status:'ready'}]){
  const untrusted=helper(['unknown-selected'],{preparation:{'unknown-selected':preparation}});
  const status=await f.library.readiness(untrusted);assert.equal(status.ready,false);assert.equal(status.documents[0].error.code,'MANUAL_MISSING');assert.deepEqual(await f.library.loadHelperAnalyses(untrusted),[]);
 }
});

test('portable plan hashes alone cannot authorize aliases outside the selected manual ID',async()=>{
 const f=await fixture();await f.save('b');await f.index('b');
 const untrusted=helper(['unknown-selected'],{plan:{documents:[{record:{...f.records.get('b'),id:'unknown-selected'}}]},preparation:{'unknown-selected':{recordId:'b',status:'ready'}}});
 assert.equal((await f.library.readiness(untrusted)).ready,false);assert.deepEqual(await f.library.loadHelperAnalyses(untrusted),[]);
});

test('byte-verified bundle aliases remain usable and are rechecked against their expected hash',async()=>{
 const f=await fixture();await f.save('b');await f.index('b');
 const verified=helper(['imported-selected'],{preparation:{'imported-selected':{recordId:'b',hash:f.records.get('b').sha256,bytesVerified:true,verification:'helper-bundle-sha256',status:'saved'}}});
 assert.equal((await f.library.readiness(verified)).ready,true);assert.equal((await f.library.loadHelperAnalyses(verified))[0].manualId,'b');
 f.files.set('b',pdf('other-edition'));assert.equal((await f.library.readiness(verified)).ready,false);assert.deepEqual(await f.library.loadHelperAnalyses(verified),[]);
});
