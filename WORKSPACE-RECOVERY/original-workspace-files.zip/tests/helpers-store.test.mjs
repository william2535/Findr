import test from 'node:test';
import assert from 'node:assert/strict';
import {validatePDF} from '../public/app/engine.mjs';
import {
  HELPERS_KEY, createHelpersStore, normalizeHelpersStore, mergeHelperSnapshot,
  migrateLegacyHelpers, findLegacyHelper, helpersUsingManual, validateHelperManifest, readHelperBundle,
} from '../public/app/helpers-store.mjs';

const conversation = (id, text = id, updatedAt = 1) => ({id, title: id, messages: [{id: `${id}-message`, role: 'user', text, createdAt: updatedAt}], createdAt: 1, updatedAt, ui: {draft: 'unsent question'}});
const helper = (id, extras = {}) => ({id, name: `Helper ${id}`, discipline: 'fire', scope: {kind: 'panel', manufacturer: 'Synthetic', model: 'Training panel', confirmed: false}, manualIds: [], requiredManualIds: [], createdAt: 1, updatedAt: 1, conversations: [], activeConversationId: null, preparation: {}, ...extras});
const helperStore = helpers => ({schemaVersion: 1, activeHelperId: helpers[0]?.id || null, helpers, migration: {sources: []}});
const tick = () => new Promise(resolve => setImmediate(resolve));

// A transaction scheduler, including chained requests and exclusive write locks.
// Staged values become observable only after commit; abort rolls all stores back.
function database(initial = {}, options = {}) {
  const data = Object.fromEntries(['settings', 'manuals', 'files'].map(name => [name, new Map(Object.entries(structuredClone(initial[name] || {})))]));
  const transactions = [], queue = []; let active = null;
  function activate() {
    if (active || !queue.length) return;
    active = queue.shift(); active.start();
  }
  return {
    data, transactions,
    release() { options.holdCommit = false; active?.schedule(); },
    failCommit(value) { options.failCommit = value; },
    transaction(stores, mode) {
      const descriptor = {stores: [...stores], mode}; transactions.push(descriptor);
      const requests = []; let staged, pending = 0, finished = false, scheduled = false;
      const complete = () => {
        if (finished || active !== entry || pending || requests.length || options.holdCommit) return;
        if (mode === 'readwrite' && options.failCommit) { tx.error = new Error('Synthetic quota failure'); tx.onerror?.(); tx.abort(); return; }
        if (mode === 'readwrite') for (const name of stores) data[name] = staged[name];
        finished = true; active = null; tx.oncomplete?.(); activate();
      };
      const schedule = () => {
        if (scheduled || active !== entry || finished) return;
        scheduled = true;
        setImmediate(() => {
          scheduled = false;
          if (finished) return;
          const action = requests.shift();
          if (action) { pending++; action(); pending--; schedule(); }
          else complete();
        });
      };
      const tx = {
        error: null,
        abort() {
          if (finished) return;
          finished = true;
          const index = queue.indexOf(entry); if (index >= 0) queue.splice(index, 1);
          if (active === entry) active = null;
          queueMicrotask(() => { tx.onabort?.(); activate(); });
        },
        objectStore(name) {
          assert.ok(stores.includes(name), `${name} belongs to transaction`);
          const enqueue = fn => { const request = {}; requests.push(() => { request.result = clone(fn()); request.onsuccess?.(); }); schedule(); return request; };
          return {
            get: key => enqueue(() => staged[name].get(key)),
            getAll: () => enqueue(() => [...staged[name].values()]),
            put(value, key) {
              assert.equal(mode, 'readwrite');
              if (options.failPut === name) throw new Error('Synthetic write failure');
              const snapshot = clone(value), actualKey = key === undefined ? snapshot.id : key;
              requests.push(() => staged[name].set(actualKey, snapshot)); schedule(); return {};
            },
          };
        },
      };
      const entry = {schedule, start() { staged = Object.fromEntries(stores.map(name => [name, new Map([...data[name]].map(([key, value]) => [key, clone(value)]))])); schedule(); }};
      queue.push(entry); queueMicrotask(activate);
      return tx;
    },
  };
}
const clone = value => structuredClone(value);
const contents = db => Object.fromEntries(Object.entries(db.data).map(([name, map]) => [name, Object.fromEntries(map)]));
const pdf = label => new Blob([`%PDF-1.7\n1 0 obj\n<< /Type /Catalog /Label (${label}) >>\nendobj\n%%EOF\n`], {type: 'application/pdf'});

async function bundleFixture() {
  const file = pdf('document one'), hash = await validatePDF(file), second = pdf('unrelated');
  const original = helper('original', {name: 'Détecteur — 楼层', manualIds: ['catalogue-id'], requiredManualIds: ['catalogue-id'], preparation: {'catalogue-id': {status: 'ready', recordId: 'shared-id', hash, processorVersion: 'v1'}}, conversations: [conversation('chat', 'Quoted source', 2)], activeConversationId: 'chat'});
  original.conversations[0].messages[0].sourceRefs = [{manualId: 'shared-id', contentHash: hash, page: 7, excerpt: 'Exact documented fact.'}];
  original.conversations[0].questionState = {id: 'quick', messages: original.conversations[0].messages, pendingGeneration: null};
  const db = database({settings: {[HELPERS_KEY]: helperStore([original]), preferences: {keep: true}}, manuals: {'shared-id': {id: 'shared-id', title: 'Document one', fileHash: hash, bytes: file.size, models: ['Training panel']}}, files: {'shared-id': file, unrelated: second}});
  return {db, store: createHelpersStore(async () => db), original, file, hash};
}

test('Helpers have no small count cap; a stale snapshot cannot erase another Helper', async () => {
  const initial = Array.from({length: 130}, (_, index) => helper(`helper-${index}`, {conversations: [conversation(`chat-${index}`)], activeConversationId: `chat-${index}`}));
  const db = database({settings: {[HELPERS_KEY]: helperStore(initial), preferences: {keep: true}}}), store = createHelpersStore(async () => db);
  await Promise.all([store.saveHelper(helper('new-a')), store.saveHelper(helper('new-b'))]);
  await store.saveHelper({...initial[0], name: 'Renamed'});
  const state = await store.loadHelpers({migrate: false});
  assert.equal(state.helpers.length, 132);
  assert.equal(state.helpers.find(item => item.id === 'helper-0').name, 'Renamed');
  assert.deepEqual(state.helpers.find(item => item.id === 'helper-129'), initial[129]);
  assert.deepEqual(db.data.settings.get('preferences'), {keep: true});
});

test('conversation saves and stale preparation saves retain every committed transcript and draft', async () => {
  const old = helper('same', {conversations: [conversation('one')], activeConversationId: 'one'}), db = database({settings: {[HELPERS_KEY]: helperStore([old])}}), store = createHelpersStore(async () => db);
  const newer = conversation('one', 'Updated answer', 5); newer.messages.push({id: 'follow-up', role: 'assistant', text: 'Documented answer', createdAt: 5});
  await store.saveHelperConversation('same', newer);
  await store.saveHelperConversation('same', conversation('two', 'Independent', 6));
  await store.saveHelper({...old, preparation: {doc: {status: 'cancelled', progress: null}}, updatedAt: 7});
  const state = await store.loadHelpers({migrate: false}), saved = state.helpers[0];
  assert.equal(saved.conversations.length, 2);
  assert.equal(saved.conversations.find(item => item.id === 'one').messages[0].text, 'Updated answer');
  assert.equal(saved.conversations.find(item => item.id === 'one').messages.length, 2);
  assert.equal(saved.conversations.find(item => item.id === 'two').ui.draft, 'unsent question');
});

test('rename is atomic, empty names reject, and deleting one Helper retains all shared resources', async () => {
  const first = helper('first', {manualIds: ['doc']}), second = helper('second', {manualIds: ['catalogue'], preparation: {catalogue: {recordId: 'doc', status: 'ready'}}});
  const initial = {settings: {[HELPERS_KEY]: helperStore([first, second]), 'manual-index:hash:version': {index: true}, 'assistant-model': {ready: true}}, manuals: {doc: {id: 'doc'}}, files: {doc: pdf('shared')}};
  const db = database(initial), store = createHelpersStore(async () => db);
  assert.deepEqual(helpersUsingManual(helperStore([first, second]), 'doc').map(item => item.id), ['first', 'second']);
  const renamed = await store.renameHelper('first', '  Useful name  ');
  assert.equal(renamed.name, 'Useful name');
  await assert.rejects(store.renameHelper('first', ' '), /name/);
  const state = await store.deleteHelper('first');
  assert.deepEqual(state.helpers.map(item => item.id), ['second']);
  assert.deepEqual([...db.data.manuals], [['doc', {id: 'doc'}]]);
  assert.equal(await db.data.files.get('doc').text(), await initial.files.doc.text());
  assert.deepEqual(db.data.settings.get('assistant-model'), initial.settings['assistant-model']);
  assert.ok(db.transactions.every(tx => tx.stores.join() === 'settings'));
});

test('save snapshots its input before storage opens and resolves only after commit', async () => {
  const db = database({}, {holdCommit: true}); let open;
  const waitForDB = new Promise(resolve => { open = resolve; }), candidate = helper('one', {conversations: [conversation('draft')], activeConversationId: 'draft'});
  let resolved = false;
  const pending = createHelpersStore(() => waitForDB).saveHelper(candidate).then(value => { resolved = true; return value; });
  candidate.conversations[0].messages[0].text = 'Later edit'; open(db);
  for (let index = 0; index < 5; index++) await tick();
  assert.equal(resolved, false); assert.equal(db.data.settings.has(HELPERS_KEY), false);
  db.release(); const saved = await pending;
  assert.equal(saved.conversations[0].messages[0].text, 'draft');
  saved.conversations[0].messages[0].text = 'Caller changed';
  assert.equal(db.data.settings.get(HELPERS_KEY).helpers[0].conversations[0].messages[0].text, 'draft');
});

test('quota, write failure, corrupt saved state, and cancellation preserve the prior usable data', async () => {
  const initial = {settings: {[HELPERS_KEY]: helperStore([helper('existing')]), history: [{id: 'legacy'}]}, files: {doc: pdf('keep')}};
  for (const options of [{failCommit: true}, {failPut: 'settings'}]) {
    const db = database(initial, options), before = contents(db);
    await assert.rejects(createHelpersStore(async () => db).saveHelper(helper('new')), /Synthetic .* failure/);
    assert.deepEqual(contents(db), before);
  }
  const bad = database({settings: {[HELPERS_KEY]: {schemaVersion: 9, helpers: []}}});
  await assert.rejects(createHelpersStore(async () => bad).saveHelper(helper('new')), /cannot be read/);
  assert.equal(bad.data.settings.get(HELPERS_KEY).schemaVersion, 9);
  const db = database(initial, {holdCommit: true}), store = createHelpersStore(async () => db), before = contents(db), controller = new AbortController();
  const pending = store.saveHelper(helper('cancelled'), {signal: controller.signal});
  for (let index = 0; index < 4; index++) await tick();
  controller.abort(); await assert.rejects(pending, {name: 'AbortError'}); db.release();
  assert.deepEqual(contents(db), before);
  const preCancelled = new AbortController(); preCancelled.abort(); const count = db.transactions.length;
  await assert.rejects(store.saveHelper(helper('never-open'), {signal: preCancelled.signal}), {name: 'AbortError'});
  assert.equal(db.transactions.length, count);
});

test('legacy migration is repeatable, wraps complete engine states, and never alters originals', async () => {
  const quick = {schemaVersion: 1, activeId: 'q1', conversations: [{...conversation('q1'), mode: 'quick-questions', equipment: [{id: 'e', manufacturer: 'Synthetic', model: 'Panel X', confirmed: false}], activeEquipmentId: 'e', manuals: [{manualId: 'pdf'}], answers: [{sourceRefs: [{manualId: 'pdf', page: 8}]}]}]};
  const archived = {id: 'case', started: 2, panel: {id: 'panel', brand: 'Synthetic', model: 'Panel X', category: 'fire', record_ids: ['pdf']}, diagnosticChat: {messages: [{id: 'old', role: 'user', text: 'Older snapshot'}]}};
  const current = {...archived, diagnosticChat: {identity: {confirmedEquipment: false}, messages: [{id: 'current', role: 'user', text: 'Current snapshot', sourceRefs: [{page: 2}]}]}};
  const legacy = {'quick-questions-v1': quick, history: [archived], session: current};
  const db = database({settings: legacy}), store = createHelpersStore(async () => db);
  const state = await store.loadHelpers();
  assert.equal(state.helpers.length, 2);
  const questions = findLegacyHelper(state, {kind: 'questions', sourceId: 'q1'}), savedCase = findLegacyHelper(state, {kind: 'case', sourceId: 'case'});
  assert.deepEqual(questions.conversations[0].questionState, quick.conversations[0]);
  assert.equal(questions.conversations[0].mode, 'helper');
  assert.equal(savedCase.conversations[0].activeChannel, 'diagnostic');
  assert.equal(savedCase.conversations[0].messages[0].text, 'Current snapshot');
  assert.deepEqual(savedCase.conversations[0].diagnosticSession, current);
  assert.equal(questions.scope.confirmed, false);
  assert.deepEqual(Object.fromEntries([...db.data.settings].filter(([key]) => key !== HELPERS_KEY)), legacy);
  db.data.settings.set('session', {...current, notes: 'Changed after migration'});
  assert.deepEqual((await store.loadHelpers()).helpers, state.helpers);
  await store.deleteHelper(questions.id);
  assert.equal((await store.loadHelpers()).helpers.length, 1, 'Deleted migrated Helper must not reappear');
  db.data.settings.set('session', {id: 'new-later-case', panel: {}, started: 9});
  assert.equal((await store.loadHelpers()).helpers.length, 2, 'New legacy source can migrate later');
});

test('malformed legacy records are retained with a warning without blocking valid Helpers', () => {
  const value = migrateLegacyHelpers(undefined, {'quick-questions-v1': {conversations: [null, conversation('good')]}, history: {broken: true}}, 10);
  assert.equal(value.helpers.length, 1);
  assert.ok(value.migration.warnings.length >= 2);
  assert.equal(normalizeHelpersStore(value).helpers[0].conversations[0].questionState.id, 'good');
});

test('manifest export and import retain all conversations but never claim portable readiness', async () => {
  const {store, original, db} = await bundleFixture(), manifest = await store.exportHelper('original');
  assert.equal(manifest.portability.pdfsIncluded, false);
  assert.equal(manifest.portability.readyOnImport, false);
  assert.deepEqual(manifest.portability.missingManualIds, ['catalogue-id']);
  assert.deepEqual(manifest.helper.conversations, original.conversations);
  const imported = await store.importHelper(JSON.stringify(manifest), {newId: 'copy'});
  assert.equal(imported.id, 'copy'); assert.equal(imported.conversations[0].helperId, 'copy');
  assert.deepEqual(imported.conversations[0].messages, original.conversations[0].messages);
  assert.equal(imported.preparation['catalogue-id'].status, 'missing');
  assert.equal(imported.portability.readyOnImport, false);
  assert.equal(db.data.manuals.size, 1);
  assert.equal((await store.loadHelpers({migrate: false})).helpers.length, 2);
  const before = contents(db);
  await assert.rejects(store.importHelper(manifest, {newId: 'original'}), /already exists/);
  assert.deepEqual(contents(db), before);
});

test('bundle carries exact PDF bytes and Unicode manifest, imports atomically, and reuses shared bytes by hash', async () => {
  const {store, file, hash, original} = await bundleFixture(), bundle = await store.exportHelperBundle('original');
  const parsed = await readHelperBundle(bundle);
  assert.equal(parsed.manifest.helper.name, original.name);
  assert.equal(parsed.manifest.portability.pdfsIncluded, true);
  assert.equal(parsed.manifest.portability.modelIncluded, false);
  assert.deepEqual(new Uint8Array(await parsed.files[0].blob.arrayBuffer()), new Uint8Array(await file.arrayBuffer()));
  const destination = database({settings: {preferences: {keep: true}}}), target = createHelpersStore(async () => destination);
  const imported = await target.importHelper(bundle, {newId: 'first-copy'});
  assert.equal(imported.preparation['catalogue-id'].hash, hash);
  assert.equal(imported.preparation['catalogue-id'].recordId, 'shared-id');
  assert.equal(imported.preparation['catalogue-id'].status, 'saved');
  assert.equal(imported.preparation['catalogue-id'].processorVersion, null);
  assert.equal(destination.data.manuals.size, 1); assert.equal(destination.data.files.size, 1);
  assert.equal(destination.transactions[0].stores.join(','), 'settings,manuals,files');
  await target.importHelper(bundle, {newId: 'second-copy'});
  assert.equal(destination.data.manuals.size, 1); assert.equal(destination.data.files.size, 1);
  assert.equal(destination.data.settings.get(HELPERS_KEY).helpers.length, 2);
  assert.deepEqual(destination.data.settings.get('preferences'), {keep: true});
});

test('import never overwrites a different PDF under an existing document ID', async () => {
  const {store} = await bundleFixture(), bundle = await store.exportHelperBundle('original'), existing = pdf('Different document'), existingHash = await validatePDF(existing);
  const destination = database({manuals: {'shared-id': {id: 'shared-id', fileHash: existingHash}}, files: {'shared-id': existing}}), target = createHelpersStore(async () => destination);
  const imported = await target.importHelper(bundle, {newId: 'copy'});
  assert.notEqual(imported.preparation['catalogue-id'].recordId, 'shared-id');
  assert.equal(destination.data.manuals.get('shared-id').fileHash, existingHash);
  assert.equal(await destination.data.files.get('shared-id').text(), await existing.text());
  assert.equal(destination.data.files.size, 2);
});

test('invalid JSON, manifest, corrupt or truncated bundles cannot change Helpers or shared files', async () => {
  const {store, db} = await bundleFixture(), bundle = await store.exportHelperBundle('original'), manifest = await store.exportHelper('original');
  const badVersion = {...manifest, schemaVersion: 9}, duplicateConversation = clone(manifest); duplicateConversation.helper.conversations.push(clone(duplicateConversation.helper.conversations[0]));
  const badDocument = clone(manifest); badDocument.documents[0].hash = 'invalid';
  const missingBytes = clone(manifest); missingBytes.documents[0].included = true;
  const unsafe = JSON.stringify(manifest).replace('"format":', '"__proto__":{"polluted":true},"format":');
  const corruptBytes = new Uint8Array(await bundle.arrayBuffer()); corruptBytes[corruptBytes.length - 15] ^= 1;
  for (const input of ['{', badVersion, duplicateConversation, badDocument, missingBytes, unsafe, bundle.slice(0, bundle.size - 4), new Blob([bundle, 'unrecognised']), new Blob([corruptBytes])]) {
    const before = contents(db);
    await assert.rejects(store.importHelper(input, {newId: 'bad-import'}));
    assert.deepEqual(contents(db), before);
  }
  assert.equal({}.polluted, undefined);
});

test('bundle quota failure and cancellation roll back settings, manual metadata, and PDF bytes together', async () => {
  const {store} = await bundleFixture(), bundle = await store.exportHelperBundle('original');
  const initial = {settings: {[HELPERS_KEY]: helperStore([helper('prior')]), session: {id: 'old-session'}}, manuals: {old: {id: 'old'}}, files: {old: pdf('prior document')}};
  for (const options of [{failCommit: true}, {failPut: 'files'}]) {
    const db = database(initial, options), before = contents(db), destination = createHelpersStore(async () => db);
    await assert.rejects(destination.importHelper(bundle, {newId: 'copy'}), /Synthetic .* failure/);
    assert.deepEqual(contents(db), before);
  }
  const db = database(initial, {holdCommit: true}), before = contents(db), controller = new AbortController();
  const pending = createHelpersStore(async () => db).importHelper(bundle, {newId: 'cancelled-copy', signal: controller.signal});
  while (!db.transactions.length) await tick();
  for (let index = 0; index < 8; index++) await tick();
  controller.abort(); await assert.rejects(pending, {name: 'AbortError'}); db.release();
  assert.deepEqual(contents(db), before);
});

test('snapshot and import validators reject conflicting identities without mutating caller data', () => {
  const original = helper('one'), next = mergeHelperSnapshot(undefined, original);
  next.helper.name = 'caller edit'; assert.equal(original.name, 'Helper one');
  assert.throws(() => mergeHelperSnapshot(helperStore([original, original]), helper('two')), /cannot be read/);
  assert.throws(() => mergeHelperSnapshot(undefined, {...original, activeConversationId: 'absent'}), /conversation is missing/);
  assert.throws(() => validateHelperManifest({format: 'other', schemaVersion: 1, helper: original, documents: []}), /supported FINDR/);
});


test('a delayed preparation save cannot resurrect a deleted Helper', async () => {
  const original = helper('preparing'), db = database({settings: {[HELPERS_KEY]: helperStore([original])}}), store = createHelpersStore(async () => db);
  await store.deleteHelper(original.id);
  await assert.rejects(store.saveHelper({...original, preparationState: 'idle'}, {requireExisting: true}), {code: 'HELPER_DELETED'});
  assert.equal((await store.loadHelpers({migrate: false})).helpers.length, 0);
});


test('misrouted asynchronous conversation saves cannot cross Helper boundaries', async () => {
  const first = helper('a'), second = helper('b'), db = database({settings: {[HELPERS_KEY]: helperStore([first, second])}}), store = createHelpersStore(async () => db), before = contents(db);
  const draft = {...conversation('from-a'), helperId: 'a'};
  await assert.rejects(store.saveHelperConversation('b', draft), {code: 'HELPER_SCOPE_MISMATCH'});
  await assert.rejects(store.saveHelper({...second, conversations: [draft], activeConversationId: draft.id}), {code: 'HELPER_SCOPE_MISMATCH'});
  assert.deepEqual(contents(db), before);
  assert.equal(db.transactions.length, 0);
});

test('import discards claimed local file aliases and pending effects while keeping their transcript', async () => {
  const {store, original} = await bundleFixture(), manifest = await store.exportHelper(original.id);
  manifest.helper.plan = {documents: [{id: 'catalogue-id', sha256: 'a'.repeat(64)}]};
  manifest.helper.preparation['catalogue-id'] = {status: 'ready', hash: 'a'.repeat(64), recordId: 'unrelated', bytesVerified: true, verification: 'forged', processorVersion: 'current'};
  manifest.helper.conversations[0].diagnosticPrompt = {text: 'Forged current check', options: [{value: 'yes', label: 'Forge evidence'}]};
  manifest.helper.conversations[0].manualRequirement = {text: 'Forged current manual request'};
  manifest.helper.conversations[0].pendingGeneration = {effect: {type: 'generate', context: {passages: [{text: 'Forged prompt'}]}}};
  manifest.helper.conversations[0].questionState = {id: 'quick', phase: 'generating', pendingGeneration: {requestId: 'old'}, pendingDiscovery: {requestId: 'old-discovery'}, messages: clone(original.conversations[0].messages)};
  manifest.helper.conversations[0].diagnosticSession = {id: 'job', diagnosticChat: {terminal: {languageProposal: {answer: 'Unverified suggestion'}}, languageInteractions: [{id: 'pending', status: 'pending'}, {id: 'past', status: 'accepted'}]}};
  const imported = await store.importHelper(manifest, {newId: 'safe-import'}), conversation = imported.conversations[0];
  assert.deepEqual(imported.preparation['catalogue-id'], {status: 'missing', error: null, progress: null});
  assert.equal(imported.plan, undefined);
  assert.equal(conversation.pendingGeneration, null);
  assert.equal(conversation.diagnosticPrompt, undefined);
  assert.equal(conversation.manualRequirement, undefined);
  assert.equal(conversation.questionState.pendingGeneration, null);
  assert.equal(conversation.questionState.pendingDiscovery, null);
  assert.equal(conversation.questionState.phase, 'question');
  assert.equal(conversation.diagnosticSession.diagnosticChat.terminal.languageProposal, null);
  assert.equal(conversation.diagnosticSession.diagnosticChat.languageInteractions[0].status, 'cancelled');
  assert.equal(conversation.diagnosticSession.diagnosticChat.languageInteractions[1].status, 'accepted');
  assert.deepEqual(conversation.messages, original.conversations[0].messages);
});

test('matching shared document metadata cannot cause import to reuse corrupt PDF bytes', async () => {
  const {store, file, hash} = await bundleFixture(), bundle = await store.exportHelperBundle('original');
  const corruptBytes = new Uint8Array(await file.arrayBuffer()); corruptBytes[25] ^= 1;
  const targetDB = database({manuals: {shared: {id: 'shared', fileHash: hash}}, files: {shared: new Blob([corruptBytes])}}), target = createHelpersStore(async () => targetDB);
  const imported = await target.importHelper(bundle, {newId: 'copy'});
  assert.equal(imported.preparation['catalogue-id'].recordId, 'shared');
  assert.equal(await validatePDF(targetDB.data.files.get('shared'), hash), hash);
  assert.equal(targetDB.data.files.size, 1);
});
